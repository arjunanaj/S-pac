<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>Nehru Fellowship - Inclusive Minds</title>
	<meta name="description" content="Explore the Nehru Fellowship, offering young leaders transformative opportunities in policy, governance, and leadership. Learn about our comprehensive application process and how this fellowship empowers future change-makers.">
	<meta name="keywords" content="Political Consulting, Election Campaigns, Indian National Congress, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="Nehru Fellowship - Inclusive Minds">
	<meta property="og:description" content="Explore the Nehru Fellowship, offering young leaders transformative opportunities in policy, governance, and leadership. Learn about our comprehensive application process and how this fellowship empowers future change-makers.">
	<meta property="og:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x675.jpg">
	<meta property="og:url" content="https://inclusiveminds.in">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Nehru Fellowship - Inclusive Minds">
	<meta name="twitter:description" content="Explore the Nehru Fellowship, offering young leaders transformative opportunities in policy, governance, and leadership. Learn about our comprehensive application process and how this fellowship empowers future change-makers.">
	<meta name="twitter:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x627.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
    <link href="css/style.css?v=1.0.10" rel="stylesheet">
	<style>
	.selection-stage {
		text-align: center;
		padding: 20px;
	}
	.selection-stage h3 {
		margin-top: 10px;
		margin-bottom: 10px;
		font-size:1.2rem;
		font-weight:bold;
	}
	.selection-stage p {
		margin: 0;
		
	}
	.icon {
		font-size: 3rem;
		color: #e69500; 
	}
	
	.icon i {
		float:none;
	}

	@media (max-width: 768px) {
		.arrow {
			display: none; 
		}
	}
	
	@media (max-width: 991.98px) {
		.col-stage {
			flex-basis: 50%;
			max-width: 50%;
		}
		.arrow {
			display: none; 
		}
	}
	</style>
	<style>
.timeline-table-section {
    margin: 20px 0;
}

.timeline-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    background: #173d62;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
    color: #fff;
}

.timeline-table th,
.timeline-table td {
    padding: 15px;
    text-align: left;
    border: 1px solid #2a5584;
}

.timeline-table th {
    background-color: #0f2a45;
    color: #ffffff;
    border-color: #2a5584;
}

.timeline-table tbody tr:hover {
    background-color: #1f4b78;
}

.timeline-date {
    /* color: #e69500; */
    font-weight: 500;
}

.early-bird {
   /*  color: #4dff4d; */
    font-weight: 500;
}

@media (max-width: 768px) {
    .timeline-table {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
    
    .timeline-table th,
    .timeline-table td {
        padding: 12px;
        font-size: 0.9rem;
    }
}
</style>
</head>
<body style="background:#173d62">
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>		<section class="hero-section">
		<!-- Content Container -->
		<div class="container position-relative py-1">
			<div class="row align-items-center">
				<!-- Desktop View -->
				<div class="col-lg-4 d-none d-lg-block text-center">
					<img src="images/nehru-caricature.svg" class="img-fluid" alt="Nehru Caricature">
				</div>

				<!-- Desktop View: Right Text (Tagline) -->
				<div class="col-lg-8 d-none d-lg-block">
					<h2 class="tagline h1">
						BUILDING THOUGHT LEADERSHIP
					</h2>
					<h2 class="tagline h1 golden-line">
						TRANSFORMING NATION
					</h2>
				</div>
				
				<!-- Mobile View: Centered Content -->
				<div class="col-12 text-center d-lg-none">
					<img src="images/nehru-caricature.svg" class="img-fluid mb-4" alt="Nehru Caricature" style="max-width: 200px;">
					<h2 class="tagline-mobile h2">
						BUILDING THOUGHT LEADERSHIP
					</h2>
					<h2 class="tagline-mobile h2 golden-line-mobile">
						TRANSFORMING NATION
					</h2>
					
				</div>
			</div>
		</div>
	</section>
	<div class="container mt-5" style="margin-bottom:50px;" >
		<div class="row g-4">
			<div class="col">
				<div class="hero-content">
			<h1 class="display-4">Nehru Fellowship in Politics and Elections</h1>
			<p class="lead">A unique opportunity for young, progressive Indians to understand politics and elections in India.</p>
						<a href="nf/" class="btn btn-action apply-btn btn-lg mt-3">Apply Now</a>
					</div>
			</div>
		</div>
		<div class="row g-4">
			<!-- About the Fellowship -->
			<div class="col-md-6">
				<div class="info-box">
					<i class="fas fa-info-circle"></i>
					<h2 class="section-title">About the Fellowship</h2>
					<div class="clear"></div>
					<p style="text-align:justify">The Nehru Fellowship in Politics and Elections is a unique opportunity for young, progressive Indians to understand politics and elections in India. The Fellowship aims to provide unparalleled hands-on exposure to the different functions of a political consulting firm, including Campaigns, Policy Research, Political Strategy and Communications. Additionally, the Fellows may also get an opportunity to work in an election war room, or in the office of a senior politician. The fellowship aims to build a community of passionate, like-minded people who are ready to explore, broaden perspective, and gain valuable skills through an adventurous journey of consultancy in politics.</p>
				</div>
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<i class="fas fa-user-check"></i>
					<h2 class="section-title">Eligibility</h2>
					<div class="clear"></div>
					<ul>
						<li>Must be an Indian Citizen with a Bachelor's degree in any discipline.</li>
						<li>Should have hunger and intent to excel beyond expectations.</li>
						<li>Should display a sense of extreme ownership to drive work.</li>
						<li>Must be adaptable to a dynamic work environment.</li>
					</ul>
					<p>We aim to provide a platform for young Indians to participate in election campaign design and execution.</p>
				</div>
			</div>
			
			<div class="col-md-6">
				<div class="info-box">
					<i class="fas fa-question-circle"></i>
					<h2 class="section-title">Why be a Nehru Fellow?</h2>
					<div class="clear"></div>
					<ul>
						<li>Build a career in Political Consulting.</li>
						<li>Upskill yourself in Political Strategy, Research, Campaigns, Communications and Data Analytics.</li>
						<li>Be the change you wish to see in Indian Politics.</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<i class="fas fa-chart-line"></i>
					<h2 class="section-title">What to Expect</h2>
					<div class="clear"></div>
					<ul>
						<li>15 Days Orientation to Inclusive Minds and the Industry.</li>
						<li>Two-Month Training in Political Intelligence and Strategy.</li>
						<li>Rotational Stints in Different Verticals.</li>
						<li>Be a part of a State Election Campaign.</li>
					</ul>
				</div>
			</div>
			<div class="col-md-12">
				<div class="info-box">
					<i class="fas fa-tasks"></i>
					<h2 class="section-title">Selection Process</h2>
					<div class="clear"></div>
					<div class="row justify-content-center align-items-center">
						<div class="col-md-2 col-stage selection-stage">
							<div class="icon"><i class="fas fa-file-alt"></i></div> 
							<h3>Preliminary Round</h3>
							<p>Applicants submit educational background, work experience, and an essay.</p>
						</div>
						<div class="col-md-1 arrow">
							<i class="fas fa-arrow-right"></i>
						</div>
						<div class="col-md-2 col-stage selection-stage">
							<div class="icon"><i class="fas fa-edit"></i></div>
							<h3>Video Assessment</h3>
							<p>Shortlisted candidates submit video presentations on a case study.</p>
						</div>
						<div class="col-md-1 arrow">
							<i class="fas fa-arrow-right"></i>
						</div>
						<div class="col-md-2 col-stage selection-stage">
							<div class="icon"><i class="fas fa-users"></i></div>
							<h3>Group Discussion</h3>
							<p>Shortlisted candidates from the video round will participate in the online group discussion.</p>
						</div>
						<div class="col-md-1 arrow">
							<i class="fas fa-arrow-right"></i>
						</div>
						<div class="col-md-2 col-stage selection-stage">
							<div class="icon"><i class="fas fa-user-tie"></i></div> <!-- Replace with appropriate icon -->
							
							<h3>Personal Interview</h3>
							<p>Selected candidates undergo a final interview.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12">
    <div class="info-box">
        <i class="fas fa-clock"></i>
        <h2 class="section-title">Selection Process Timeline</h2>
        <div class="clear"></div>
        <div class="timeline-table-section">
            <table class="timeline-table">
                <thead>
                    <tr>
                        <th>Stages</th>
                        <th>Early Bird</th>
                        <th>Regular</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Application</td>
                        <td class="early-bird">Feb 1st - 20th, 2025</td>
                        <td class="timeline-date">Feb 21st - Mar 10th, 2025</td>
                    </tr>
                    <tr>
                        <td>Video Assessment</td>
                        <td class="early-bird">Feb 27th - 28th, 2025</td>
                        <td class="timeline-date">Mar 17th - 18th, 2025</td>
                    </tr>
                    <tr>
                        <td>Group Discussion</td>
                        <td class="early-bird">Mar 8th - 17th, 2025</td>
                        <td class="timeline-date">Mar 26th - Apr 4th, 2025</td>
                    </tr>
                    <tr>
                        <td>Personal Interview</td>
                        <td class="early-bird">Mar 21st - 31st, 2025</td>
                        <td class="timeline-date">Apr 5th - 15th, 2025</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


			<div class="col-md-6">
				<div class="info-box">
					<i class="fas fa-money-bill-wave"></i>
					<h2 class="section-title">Remuneration</h2>
					<div class="clear"></div>
					<p>Fellows will receive a monthly stipend of Rs. 75,000.</p>
				</div>
			</div>

			<!-- Apply Now Section -->
			<div class="col-md-6">
				<div class="info-box text-start" id="apply">
					<div class="">
						<i class="fas fa-paper-plane"></i>
						<h2 class="section-title">Ready to Join?</h2>
						<div class="clear"></div>
					</div>
					<p>Take the first step towards an exciting career in politics and elections.</p>
										<a href="nf/" class="btn apply-btn mt-3">Apply Now</a>
									</div>
			</div>
		</div>
	</div>
	
	<!-- Testimonials Section -->
	<section class="testimonials-section py-5">
		<div class="container">
			<h2 class="text-center mb-4">Testimonials from Our Fellows</h2>
			<div class="row">
				<div class="col-md-4 mb-4">
					<div class="testimonial">
						<p class="testimonial-text">"The fellowship has been transformative, offering an insider's view of politics. Especially, working on the Telangana assembly election deepened my understanding of socio-economic factors in electoral outcomes. It enhanced my ability to analyse events, predict developments, and solve problems."</p>
						<p class="testimonial-author">- Juned (Batch 2023)</p>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="testimonial">
						<p class="testimonial-text">"This fellowship taught me that no matter how much you read, write, and keep yourself updated with current issues, Indian democracy will keep you guessing, and learning, and the Nehru Fellowship was the perfect conduit for me to understand this one fact."</p>
						<p class="testimonial-author">- Vikram (Batch 2023)</p>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="testimonial">
						<p class="testimonial-text">"As a Nehru Fellow, I was part of North-East India's Political Intelligence team to understand linkages between electoral processes and governance lodged in the narrative of identity politics. My role entailed envisioning political consulting interventions embedded in vernacular politics and idioms that resonate with communities in a particular regional setting."</p>
						<p class="testimonial-author">- Sunil Pradhan (Batch 2023)</p>
					</div>
				</div>
			</div>
		</div>
	</section>
    <footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>	
</body>
</html>