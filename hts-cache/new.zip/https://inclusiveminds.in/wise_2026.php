<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>WISE 2026 - Women in Strategy and Electioneering - Inclusive Minds</title>
	<meta name="description" content=" Meet our WISE Trainees - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta name="keywords" content="WISE, Women in Strategy, Political Consulting, Election Campaigns, Women Leadership, Political Strategy, Inclusive Minds, Women Empowerment">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="WISE 2026 - Women in Strategy and Electioneering - Inclusive Minds">
	<meta property="og:description" content="Meet our WISE Trainees 2026 - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta property="og:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta property="og:url" content="https://inclusiveminds.in/wise_2026.php">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="WISE 2026 - Women in Strategy and Electioneering - Inclusive Minds">
	<meta name="twitter:description" content="Meet those who onboarded to WISE 2026 - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta name="twitter:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@19.1.3/dist/lazyload.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
	<link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
    .modal-body img {
        float:left;
    }
	body {color:#222;}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>	<section class="about wise-section fellow-section py-5" id="about">
		<div class="container">
			<div class="row" style="color:#222;margin-bottom:20px;">
				<div class="col-8">
					<h2 class="fw-bold">Meet our WISE Trainees</h2>
				</div>
				<div class="col-4 text-end">
					<h2 class="text-muted">2026</h2>
				</div>
			</div>
						<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Bhumika Mahajan" class="lazy" src="images/wise/2026/Bhumika Mahajan.png">
				  <h4>Bhumika Mahajan</h4>
				  <p class="position">B.A. (Hons) Political Science student at Miranda House, University of Delhi</p>
				  <p class="additional_info" style="display:none">Bhumika Mahajan is a final-year B.A. (Hons) Political Science student at Miranda House, University of Delhi, navigating the worlds of public policy and governance through hands-on institutional experience. She has worked with the office of a Rajya Sabha MP, the National Human Rights Commission, and public policy organisations such as Manthan and Young Leaders for Active Citizenship (YLAC), contributing to legislative research, policy briefs, governance analysis, and digital advocacy. Her interests lie in understanding how democratic institutions function beyond theory and how policy decisions take shape in practice. Outside policy spaces, Bhumika turns to photography as a way of observing people, power, and the everyday nuances of public life.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Arshi Khan" class="lazy" src="images/wise/2026/Arshi Khan.png">
				  <h4>Arshi Khan</h4>
				  <p class="position">LL.B. student at Campus Law Centre, University of Delhi</p>
				  <p class="additional_info" style="display:none">Arshi is a third-year LL.B. student at Campus Law Centre, University of Delhi, with a background in Economics and History from Janki Devi Memorial College. She is passionate about legal research, criminal law, mediation and arbitration. She has honed her advocacy and problem-solving skills through national-level moot court and mediation competitions. Beyond academics, she has worked extensively with legal aid and grassroots initiatives, reflecting her commitment to social justice and public policy. She enjoys engaging with nuanced legal questions, public affairs, and rights-based advocacy in both academic and practical legal contexts.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Megha Rani Pradhan" class="lazy" src="images/wise/2026/Megha Rani Pradhan.png">
				  <h4>Megha Rani Pradhan</h4>
				  <p class="position">Masters student in Development Studies in Indian Institute of Technology, Guwahati</p>
				  <p class="additional_info" style="display:none">Megha Rani Pradhan is currently a Masters student in Development Studies in Indian Institute of Technology, Guwahati. She completed her Bachelors with Honours in Sociology from Presidency University, Kolkata. Her interests lie in the intersection of policy formulation and social entrepreneurship, with a strong interest in political communication, and grassroots governance. Her academic training equips her with skills in qualitative research, data interpretation, and field-based analysis, which she applies to understanding voter behaviour, social narratives, and policy impact. She has experience working in institutional and field settings, including engagements with state agencies and research projects. Megha is particularly interested in gender justice, social equity, and political accountability. Outside work, she enjoys debating, curating discussions, and engaging with contemporary political debates.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Charu Singh Rathore" class="lazy" src="images/wise/2026/Charu Singh Rathore.png">
				  <h4>Charu Singh Rathore</h4>
				  <p class="position">Master’s degree in Political Science from the University of Delhi</p>
				  <p class="additional_info" style="display:none">Charu holds a Master’s degree in Political Science from the University of Delhi, with a strong interest in public policy, governance, and inclusive development. She has experience in evidence-based policy analysis, field surveys, and stakeholder engagement through internships with think tanks and research institutions. Building on this foundation, she is now venturing into the field of political consulting, which sits at the intersection of people, policies, and politics. Outside work, she values meaningful conversations with friends and family, engages in reflective journaling, and enjoys listening to Sufi-ghazal traditions.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Poorvi Patil" class="lazy" src="images/wise/2026/Poorvi Patil.png">
				  <h4>Poorvi Patil</h4>
				  <p class="position">Masters of Public Policy degree at the National Law School of India University</p>
				  <p class="additional_info" style="display:none">Poorvi is a final-year student in the Masters of Public Policy degree at the National Law School of India University. Her experiences have spanned across government, grassroots organizations and civil society, from interning at the Office of the Principal Scientific Adviser, where she engaged with science-policy intersections, to working with GRAAM on social impact consulting, Praja Foundation on Urban Governance and the Mazdoor Kisan Shakti Sangathan, learning about rights-based activism and transparency movements on the field. These diverse experiences have deepened her commitment to evidence-based policymaking and participatory governance. Outside work, she enjoys reading, exploring cities and engaging with community-driven initiatives.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Aleena Paul" class="lazy" src="images/wise/2026/Aleena Paul.png">
				  <h4>Aleena Paul</h4>
				  <p class="position">Law student at Hidayatullah National Law University</p>
				  <p class="additional_info" style="display:none">Aleena Paul is a 4th-year law student at Hidayatullah National Law University with a strong academic interest in politics, public policy, criminal law and intellectual property. Her engagement with law is shaped by a broader curiosity about governance, feminist theory, and the underlying social structures that influence legal systems. She is particularly interested in how political ideas translate into lived realities and shape societies. Beyond academics, she enjoys reading history and sociology, as well as exploring museums in her spare time.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Nalanda Basu" class="lazy" src="images/wise/2026/Nalanda Basu.png">
				  <h4>Nalanda Basu</h4>
				  <p class="position">Management Studies from St. Xavier’s College, Kolkata</p>
				  <p class="additional_info" style="display:none">Nalanda Basu is a politically sharp, ground-oriented thinker who prefers working within messy realities rather than theorising from a distance. A graduate in Management Studies from St. Xavier’s College, Kolkata, she is currently an SBI Youth for India Fellow, working to revive a 400-year-old embroidery tradition in a remote village along India’s western border in Bikaner, Rajasthan. Shaped by her NCC experience, she brings discipline, field sensitivity, and a strong narrative instinct to her work. Curious, opinionated, and analytically restless, she moves between data, lived experience, and storytelling. She finds balance in reflective writing, fiction novels, visual journaling, and dance, and views the world through a historical lens believing that power belongs to those who can read patterns early and act before repetition becomes inevitable.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Riya Mishra" class="lazy" src="images/wise/2026/Riya Mishra.png">
				  <h4>Riya Mishra</h4>
				  <p class="position">Political Science student at the University of Delhi</p>
				  <p class="additional_info" style="display:none">Riya is a Political Science student at the University of Delhi who believes learning is shaped as much by people and experiences as by classrooms. She is drawn to understanding politics through everyday interactions, grassroots realities, and the stories people carry. She enjoys reading, writing poetry, debating, learning languages, and spending time in conversations that allow for listening, reflection, and disagreement. These spaces influence how she thinks and grows. She is interested in contributing to change through careful research and inclusive dialogue, and is also a vitiligo advocate and TEDx speaker.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Mohini Choubey" class="lazy" src="images/wise/2026/Mohini Choubey.png">
				  <h4>Mohini Choubey</h4>
				  <p class="position">Political Science (Honours) with a minor in Geography at Miranda House, University of Delhi</p>
				  <p class="additional_info" style="display:none">Mohini is pursuing Political Science (Honours) with a minor in Geography at Miranda House, University of Delhi. She is a recipient of Miranda House’s Special Appreciation for the Award of Excellence and currently serves as a National Fellow with the Princeton Foundation for Peace and Learning. Her academic interests span across a broad spectrum, covering areas like public policy, planning studies, human rights, gender justice, and cultural studies, which manifest in tangible forms through her active engagement in research, editorial leadership, and menstrual-equity advocacy. Beyond academics, she enjoys writing, public speaking, photography, and visual storytelling.</p>
				</div>
				</div>
							</div>
					</div>
	</section>
	<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
	<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body team-modal">
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
	
	<script>
	$(document).ready(function() {
		$('[data-bs-target="#modal"]').click(function() {
			$('#modal h5.modal-title').html("<h4>"+$(this).find('h4').html()+"</h4>");
			$('#modal .modal-body').html('<img src="'+$(this).find('img').attr('src')+'" />');
			$('#modal .modal-body').append("<p direction='rtr'>"+$(this).find('p.additional_info').html()+"</p>");
		});
	});
	</script>
</body>
</html>