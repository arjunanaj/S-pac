<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <title>Inclusive Minds: Be the change</title>
	
    <meta name="description" content="Inclusive Minds: Leading political consultants aligned with the Indian National Congress. Specializing in data-driven campaigns, policy advisory, and strategic research to drive impactful electoral outcomes. Headquartered in Bengaluru.">
    <meta name="keywords" content="Political Consulting, Election Campaigns, Indian National Congress, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
    <meta name="author" content="Inclusive Minds">
    <meta name="robots" content="index, follow">
    
    <meta property="og:title" content="Inclusive Minds: Be the change">
    <meta property="og:description" content="Inclusive Minds: Leading political consultants aligned with the Indian National Congress. Specializing in data-driven campaigns, policy advisory, and strategic research to drive impactful electoral outcomes. Headquartered in Bengaluru.">
    <meta property="og:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x675.jpg">
    <meta property="og:url" content="https://inclusiveminds.in">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Inclusive Minds: Be the change">
    <meta name="twitter:description" content="Inclusive Minds: Leading political consultants aligned with the Indian National Congress. Specializing in data-driven campaigns, policy advisory, and strategic research to drive impactful electoral outcomes. Headquartered in Bengaluru.">
    <meta name="twitter:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x627.jpg">
    <meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
    
    <link href="css/style.css?v=1.0.12" rel="stylesheet">
	
    <style>
		.video-section {
			position: relative;
			width: 100%;
			overflow: hidden;
			background-color: #102B59;
		}

		.video-container {
			position: relative;
			width: 100%;
			height: 0;
			padding-bottom: 56.25%;
		}

		.video-placeholder {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			/* background-image: url('images/video-poster.jpg'); */
			background-size: cover;
			background-position: center;
			opacity: 1;
			transition: opacity 0.5s ease-in-out;
		}

		.video-wrapper {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			opacity: 0;
			transition: opacity 0.5s ease-in-out;
		}

		.video-wrapper.loaded {
			opacity: 1;
		}

		.video-section video {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			object-fit: cover;
		}
		</style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>
    <section class="video-section">
		<div class="video-container">
			<div class="video-placeholder"></div>
			<div class="video-wrapper">
				<video id="heroVideo" 
					   playsinline 
					   muted 
					   loop
					   preload="auto"
					   aria-hidden="true">
					<source src="images/mainvideo.webm" type="video/webm">
					<source src="images/mainvideo.mp4" type="video/mp4">
				</video>
			</div>
		</div>
	</section>

    <section class="about-section py-5" id="about">
        <div class="container">
            <h2 class="text-center mb-4">About Us</h2>
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <p class="text-center">Inclusive Minds is a 360° political consulting firm aligned with the Indian National Congress. We offer electioneering, policy and governance advisory to support our clients. Our team comprises both seasoned political consultants who have contributed across the political spectrum from the inception of this space, and other professionals with varied expertise who joined us through the journey.</p>
                    
                    <h4 class="text-center mt-4 mb-3">Our campaign initiatives include:</h4>
                    <div class="row justify-content-center">
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-file-alt fa-2x mb-2"></i>
                                <p>Policy suggestions</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-users fa-2x mb-2"></i>
                                <p>Grassroots campaigns</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-handshake fa-2x mb-2"></i>
                                <p>Stakeholder alignment</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-bullhorn fa-2x mb-2"></i>
                                <p>High-octane narrative-defining events</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-share-alt fa-2x mb-2"></i>
                                <p>Social media amplification</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <div class="initiative-box p-3 text-center">
                                <i class="fas fa-photo-video fa-2x mb-2"></i>
                                <p>Effective multimedia strategy and campaigns</p>
                            </div>
                        </div>
                    </div>

                    <p class="text-center mt-4">We aim to promote and facilitate constructive dialogue and interaction among young mission-driven professionals who want to revolutionise the field of electioneering, policy-making and governance advisory. We also aspire to collaborate with like-minded individuals to find common ground on the most important issues and elevate them to positions where they can affect real change.</p>
                    
                    <p class="text-center mt-4"><strong>We are headquartered in Bengaluru.</strong></p>
                </div>
            </div>
        </div>
    </section>

    <section class="our-work-section py-5" id="work">
        <div class="container">
            <h2 class="text-center mb-4">Our Work</h2>
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <p class="text-center mb-5">We specialise in building data-driven 360-degree election campaigns, offering strategic advice to the client and supporting on-ground implementation of strategies. Inclusive Minds has six internal verticals that work together to deliver cutting-edge political consulting services to the INC.</p>
                    
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-chart-bar fa-3x mb-3"></i>
                                <h4>Data Analytics</h4>
                                <p>Builds models to identify and forecast voting patterns, tracks performance of political leaders, and analyses media and social media trends.</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-bullseye fa-3x mb-3"></i>
                                <h4>Growth and Performance Marketing</h4>
                                <p>Identifies, develops and optimises marketing strategies and channels to drive organisational growth.</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-chess fa-3x mb-3"></i>
                                <h4>Political Strategy</h4>
                                <p>Tracks the political pulse of the electorate and proposes winning electoral strategies through evidence-based research.</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-search fa-3x mb-3"></i>
                                <h4>Strategic Research</h4>
                                <p>Analyses government performance, identifies policy and electoral issues, and proposes recommendations using various research methods.</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-comments fa-3x mb-3"></i>
                                <h4>Communications</h4>
                                <p>Creates and delivers high-impact content across media platforms, and develops actionables from news analysis.</p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="vertical-box p-4">
                                <i class="fas fa-tasks fa-3x mb-3"></i>
                                <h4>Campaigns and Operations</h4>
                                <p>Creates integrated campaigns, manages brand, and supports implementation of on-ground campaigns, including outcome measurement.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="join" class="join-us-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h2 class="text-center mb-4">Join Us</h2>
                    <p class="text-center mb-4">
                        We are passionate about our democracy and the politics that shape the world around us. We draw on some of the sharpest minds from distinguished institutions and diverse professional backgrounds to help us achieve our goal. The team brings in decades of experience in building electoral strategies that spark conversations, effect change and help shape electoral and legislative ecosystems in our country.
                    </p>
                    <div class="text-center">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind/" class="btn btn-action btn-lg apply-btn" target="_blank">Apply Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
	document.addEventListener('DOMContentLoaded', function() {
		const video = document.getElementById('heroVideo');
		const wrapper = document.querySelector('.video-wrapper');
		const placeholder = document.querySelector('.video-placeholder');
		let isVideoLoaded = false;

		// Start loading the video immediately but hidden
		function loadVideo() {
			// Create a promise to handle video loading
			const videoLoadPromise = new Promise((resolve) => {
				// Check if video is already loaded
				if (video.readyState >= 3) {
					resolve();
				} else {
					// Wait for enough data to be loaded
					video.addEventListener('canplay', function onCanPlay() {
						video.removeEventListener('canplay', onCanPlay);
						resolve();
					});
				}
			});

			// When video is ready
			videoLoadPromise.then(() => {
				if (!isVideoLoaded) {
					isVideoLoaded = true;
					// Start playing
					video.play().then(() => {
						// Fade in video
						wrapper.classList.add('loaded');
						// Fade out placeholder
						placeholder.style.opacity = '0';
					}).catch(() => {
						// Fallback if autoplay fails
						placeholder.style.opacity = '1';
					});
				}
			});
		}

		// Start loading immediately if not mobile
		if (window.innerWidth > 768) {
			loadVideo();
		}

		// Handle visibility changes
		document.addEventListener('visibilitychange', () => {
			if (!document.hidden && isVideoLoaded) {
				video.play();
			}
		});

		// Handle mobile devices
		if (window.innerWidth <= 768) {
			// Optional: load video on scroll or other trigger
			const observer = new IntersectionObserver((entries) => {
				if (entries[0].isIntersecting && !isVideoLoaded) {
					loadVideo();
				}
			}, { threshold: 0.1 });
			
			observer.observe(video);
		}
	});
	</script>
</body>
</html>