<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>Meet Our Fellows 2024 - Inclusive Minds</title>
	<meta name="description" content="Explore the profiles of our fellows from 2024, highlighting their roles as emerging leaders driving positive change in policy, governance, and social development. Learn about their innovative approaches and contributions towards creating a better future.">
	<meta name="keywords" content="Political Consulting, Election Campaigns, Indian National Congress, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="Meet Our Fellows 2024 - Inclusive Minds">
	<meta property="og:description" content="Explore the profiles of our fellows from 2024, highlighting their roles as emerging leaders driving positive change in policy, governance, and social development. Learn about their innovative approaches and contributions towards creating a better future.">
	<meta property="og:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta property="og:url" content="https://inclusiveminds.in">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Meet Our Fellows 2024 - Inclusive Minds">
	<meta name="twitter:description" content="Explore the profiles of our fellows from 2024, highlighting their roles as emerging leaders driving positive change in policy, governance, and social development. Learn about their innovative approaches and contributions towards creating a better future.">
	<meta name="twitter:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
	<link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
	.modal-body {
        
    }

    .modal-body img {
        float:left;
    }
	body {color:#222;}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>	<section class="about fellow-section py-5" id="about">
    <div class="container">
		<div class="row" style="color:#222;margin-bottom:20px;">
			<div class="col-8">
				<h2 class="fw-bold">Meet our Fellows</h2>
			</div>
			<div class="col-4 text-end">
				<h2 class="text-muted">2024</h2>
			</div>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Shriya" class="lazy" src="images/nfs/Shriya.png">
				  <h4>Shriya</h4>
				  <p class="position">BA Political Science (Hons.), Fergusson College</p>
				  <p class="additional_info" style="display:none">Shriya Sanjay Mahadik, from Ratnagiri, Maharashtra, is passionate about politics and rural empowerment. She holds a Bachelor's degree in Political Science from Fergusson College, Pune, and recently secured AIR 28 in SSCW (Non-tech) for OTA. Her journey from rural upbringing to urban education has fueled her commitment to rural empowerment, envisioning a future with better tools and opportunities for these communities. Shriya aims to challenge political stereotypes, believing in the transformative power of noble politics. She also enjoys occasionally strumming the ukulele, reading mythological fiction, photography, and art.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Azeem" class="lazy" src="images/nfs/Azeem.png">
				  <h4>Azeem</h4>
				  <p class="position">Masters in Computer Applications, PES University, Bengaluru</p>
				  <p class="additional_info" style="display:none">Azeem Ali, from the fort city of Chitradurga in Karnataka, holds a master's degree in computer applications from PES University Bengaluru and is a BCA gold medallist from Davangere University. His professional trajectory began as a software engineering intern at Tuebora Software Private Limited and progressed to the establishment of Loopit Digital, a social media marketing agency. His passion for politics and policy finds its roots in personal experiences. Having proudly represented Karnataka in the Parliament of India, he is driven by his background, often marginalised. Through the Nehru Fellowship, he aspires to contribute meaningfully to political sphere. His aim is to utilise the potency of social media to safeguard democracy.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Garima" class="lazy" src="images/nfs/Garima-Goel.png">
				  <h4>Garima</h4>
				  <p class="position">Research Masters, King’s College London</p>
				  <p class="additional_info" style="display:none">Garima Goel has a background in social science research and communications. She is a political science graduate from the University of Hyderabad, with a Research Masters from King’s College London. She also has experience in reporting with Reuters and teaching. As a Nehru Fellow, she seeks to engage with the emerging political consultancy space and understand the inner workings of elections, particularly in the run-up to India’s crucial 2024 general election.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Samiksha" class="lazy" src="images/nfs/Samiksha.png">
				  <h4>Samiksha</h4>
				  <p class="position">BA (Hons.) Multimedia and Mass Communication, University of Delhi</p>
				  <p class="additional_info" style="display:none">Samiksha, a Delhi University graduate with a honours degree in Multimedia and Mass Communication, considers herself a jack of all trades, on her way to mastering them all, one at a time. Her journey began with an NGO during her first year of graduation, sparking her interest in politics and public service. Over the next two years, she worked with the Hindustan Times, the Delhi Commission for Protection of Child Rights, and the Ministry of Housing and Urban Affairs. In her free time, she can be found singing her heart out, sketching or buried with her nose in a book.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rohit" class="lazy" src="images/nfs/Rohit Kumar V.png">
				  <h4>Rohit</h4>
				  <p class="position">B.A. (Political Science, English, and History) Hons, Christ University</p>
				  <p class="additional_info" style="display:none">Hailing from Bengaluru, Rohit holds a Bachelor’s in Political Science, English, and History from Christ University. His extensive professional experience includes roles with prestigious Indian think tanks and governmental organizations such as the National Commission for Scheduled Tribes, National Maritime Foundation, Council for Strategic &amp; Defense Research, Centre for Public Policy Research, and Konrad Adenauer Stiftung. He contributed to G20 India’s Civil20 in 2023, focusing on research and coordination under the Sous-Sherpa's office. Rohit is a cinephile at heart and an ardent cricker follower. He strongly believes in living life like a test match – you win some, you lose some, and you hold strong to draw even on some.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rochana" class="lazy" src="images/nfs/Rochana B.png">
				  <h4>Rochana</h4>
				  <p class="position">BA.LLB (Hons), Symbiosis Law School, Pune</p>
				  <p class="additional_info" style="display:none">Rochana B. Hebbal is a lawyer, public policy enthusiast, and part-time educator from Davangere, Karnataka. She completed her BA.LLB (Hons) with a merit scholarship from Symbiosis Law School, Pune, driven by her aspiration to positively impact lives through law. Her journey in law revealed the profound impact of politics and policies on people's lives, inspiring her ambition to contribute actively to India's political landscape. Rochana has diverse experience, including work with Supreme Court Justice A.S. Bopanna, senior lawyers, law firms, NGOs, and a parliamentary project on &quot;Welfare of OBCs.&quot; When not discussing everything politics, sports, she can be found planning her next trek.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rutwik" class="lazy" src="images/nfs/Rutwik Khasnis.png">
				  <h4>Rutwik</h4>
				  <p class="position">MA Development - Azim Premji University</p>
				  <p class="additional_info" style="display:none">Rutwik holds an MA in Development from Azim Premji University and a BA in Economics from Christ University. His career began with two years in journalism, where he realised the power of communication and media. Subsequently transitioning into sustainability-focused research and consulting, he served as a Campaigner at Greenpeace India, advocating for sustainable food and health-centric policies. Rutwik is dedicated to preserving India as a secular, liberal nation that prioritizes inclusion and diversity. Outside of his professional endeavors, he enjoys creating culinary videos for YouTube, showcasing his skills as a chef.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Akshay" class="lazy" src="images/nfs/Akshay Bhagwat.png">
				  <h4>Akshay</h4>
				  <p class="position">Integrated M.Sc. in Physics from Indian Institute of Technology, Roorkee</p>
				  <p class="additional_info" style="display:none">Akshay Bhagwat is a Post Graduate in Nuclear Physics from IIT Roorkee. While preparing for the UPSC examination, he was influenced by diverse political thinkers ranging from Arendt and Gramsci to Aurobindo and MN Roy. From 2021 to 2023, he researched pesticide use and its impact on rural India for an environmental NGO, surveying farmers across 8 states. His professional interests span political intelligence, strategy, governance, policy, and social science research. Akshay is an avid reader of both fiction and non-fiction with a special interest in subaltern histories, and a skilled musician who has performed at some of the nicest venues in Delhi.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Chaitanya" class="lazy" src="images/nfs/Chaitanya.png">
				  <h4>Chaitanya</h4>
				  <p class="position">B.A. (Hons.) in Political Science with a minor in Environmental Studies, Ashoka University</p>
				  <p class="additional_info" style="display:none">Chaitanya is an Ashoka University graduate with a Bachelor's in Political Science and Environmental Studies. After a brief stint in content strategy, he has spent the last year and a half working in monitoring and impact evaluation at an ed-tech NGO. His passion for politics and policy stems from a desire to understand governing systems and advocate for sustainable, inclusive public spaces. Originally from Rajahmundry, a riverside town in Andhra Pradesh, Chaitanya has spent the past five years in and around Delhi. In his free time, he enjoys cooking, reading up on obscure topics, and solving puzzles.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Aarushi" class="lazy" src="images/nfs/Aarushi Shekhar.png">
				  <h4>Aarushi</h4>
				  <p class="position">MA in Politics with specialisation in International Studies, Jawaharlal Nehru University</p>
				  <p class="additional_info" style="display:none">Aarushi holds a Bachelor’s in Political Science from Lady Shri Ram College and a Master’s in Politics and International Studies from Jawaharlal Nehru University. She has previously worked at organisations such as PRS Legislative Research and Pratham NGO. Her artistic interests include a diverse range of hobbies such as playing the piano and learning classical Odissi dance. Academically, she incisively analyzes developments in India's domestic and foreign policy, aiming to cut through the chaff and provide a nuanced perspective.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Hargun" class="lazy" src="images/nfs/Hargun.png">
				  <h4>Hargun</h4>
				  <p class="position">BA (Hons) in Political Science with a minor in International Relations, Ashoka University</p>
				  <p class="additional_info" style="display:none">Raised in a defense family, Hargun embodies the quintessential army kid. Her friends describe her as a social butterfly, especially for organizing mid-day and mid-week hangouts. She holds a degree in Political Science, International Relations, and Media Studies from Ashoka University. Her passion for politics began in high school and grew during her undergrad years, where she analyzed the 2019 General Elections through data analytics and research. She also has a keen interest in foreign policy and security studies, contributing articles to publications such as ORF and E-IR.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Siddharth" class="lazy" src="images/nfs/Siddharth.png">
				  <h4>Siddharth</h4>
				  <p class="position">LLB, Government Law College, Mumbai University</p>
				  <p class="additional_info" style="display:none">Siddharth Desarda holds an LLB degree from Government Law College Mumbai and has also completed a Bachelor's in Liberal Arts, showcasing his diverse academic interests. His research focuses on interdisciplinary subjects like urbanisation, early childhood education, and migration, indicating his commitment to addressing pressing societal issues. Siddharth is deeply passionate about Indian politics, particularly grassroots movements and policy developments. He envisions a career that combines law practice with public policy work, aspiring to contribute meaningfully to the betterment of society.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Soumya" class="lazy" src="images/nfs/soumya.png">
				  <h4>Soumya</h4>
				  <p class="position">MA in Development, Azim Premji University, Bengaluru</p>
				  <p class="additional_info" style="display:none">Soumya holds a Master's degree in Development from Azim Premji University and a Bachelor's degree in Social Sciences from Tata Institute of Social Sciences (TISS). Her academic journey has been marked by active engagement in student politics and social movements. Her research pursuits are centred around urban planning, climate change, land conflicts, and women's reproductive rights. Soumya has contributed her expertise to various organisations such as Land Conflict Watch, MTV Staying Alive Foundation, Institute of Social Studies Trust and the Telangana Social Welfare Residential Schools. Driven by a passion for understanding the intricacies of Indian politics, Soumya has chosen to embark on this fellowship.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Ekshika" class="lazy" src="images/nfs/Ekshika.png">
				  <h4>Ekshika</h4>
				  <p class="position">MA in Politics with specialisation in International Studies, Jawaharlal Nehru University</p>
				  <p class="additional_info" style="display:none">Ekshika Parnami is an alumna of Jawaharlal Nehru University and holds a Bachelor's degree in Journalism (Honors) from Christ University, where she authored a thesis on the impact of service learning. She has previously worked with the Indian Express, Centre for Social Justice, and Bonobology Media. She has also prepared for the UPSC exams, aspiring to bring change to the country. Her current role at Inclusive Minds aligns with this aspiration. Additionally, she is a cinephile who enjoys writing (check out Bonobology), dancing, meditating, and curating playlists on Spotify.</p>
				</div>
				</div>
						</div>
    </div>
</section>
<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
	<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body team-modal">
            </div>
        </div>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>

<script>
$(document).ready(function() {
    $('[data-bs-target="#modal"]').click(function() {
        $('#modal h5.modal-title').html("<h4>"+$(this).find('h4').html()+"</h4>");
        $('#modal .modal-body').html('<img src="'+$(this).find('img').attr('src')+'" />');
        $('#modal .modal-body').append("<p direction='rtr'>"+$(this).find('p.additional_info').html()+"</p>");
    });
});
</script>

</body>
</html>