<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>Meet Our Fellows 2025 - Inclusive Minds</title>
	<meta name="description" content="Discover the inspiring stories of our fellows from 2025, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta name="keywords" content="Political Consulting, Election Campaigns, Indian National Congress, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="Meet Our Fellows 2025 - Inclusive Minds">
	<meta property="og:description" content="Discover the inspiring stories of our fellows from 2025, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta property="og:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta property="og:url" content="https://inclusiveminds.in">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Meet Our Fellows 2025 - Inclusive Minds">
	<meta name="twitter:description" content="Discover the inspiring stories of our fellows from 2025, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta name="twitter:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@19.1.3/dist/lazyload.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
	<link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
    .modal-body img {
        float:left;
    }
	body {color:#222;}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>	<section class="about fellow-section py-5" id="about">
		<div class="container">
			<div class="row" style="color:#222;margin-bottom:20px;">
				<div class="col-8">
					<h2 class="fw-bold">Meet our Fellows</h2>
				</div>
				<div class="col-4 text-end">
					<h2 class="text-muted">2025</h2>
				</div>
			</div>
			<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rylaa Singh Navraj" class="lazy" src="images/nfs/2025/RylaaSinghNavraj.png">
				  <h4>Rylaa Singh Navraj</h4>
				  <p class="position">BA (Political Science), Lady Shri Ram College For Women (LSR)</p>
				  <p class="additional_info" style="display:none">Rylaa Singh Navraj, a proud Dilliwali and Political Science graduate from Lady Shri Ram College, has worked as a political analyst across party lines. A total nerd at heart, she’s often solving a Rubik’s Cube, buried in books, or plotting her next travel escape. Refusing to settle for a normal life, she chases growth, thrill, and purpose every day. Passionate about India’s progress, she dreams of the day when, as Nehru envisioned, “India will awake to life and freedom”—free from the shackles of caste and creed. An India driven by a pragmatic vision of growth, innovation, and inclusive development.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Tushar Rajput" class="lazy" src="images/nfs/2025/Tushar Rajput.png">
				  <h4>Tushar Rajput</h4>
				  <p class="position">LLM (International Law), The Fletcher School of Law and Diplomacy</p>
				  <p class="additional_info" style="display:none">Tushar Rajput is a lawyer with an LL.M. in International Law from The Fletcher School of Law and Diplomacy, with studies at Harvard Law School and Harvard Kennedy School as well. He has served as a judicial intern to the Chief Justice of India and as a research assistant to the Indian Member of the UN International Law Commission. His work spans Public International Law issues, diplomatic narrative-building, and specialized areas of Trade, Investment, and Environmental Law. Selected as a Nehru Fellow for Political Consulting, Tushar thrives where law and diplomacy meet. He believes in showing up for the problems the right way - quietly, consistently, and with purpose.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Jaya Sengar" class="lazy" src="images/nfs/2025/Jaya.png">
				  <h4>Jaya Sengar</h4>
				  <p class="position">MSc (Modern South Asian Studies), University of Oxford</p>
				  <p class="additional_info" style="display:none">Jaya holds a bachelor’s degree in Politics and International Relations and an MSc in Modern South Asian Studies from the University of Oxford. Her research interests include public policy, public health, political economy, and philosophy. She previously held a teaching fellowship at Ashoka University, where she taught a course on the ethics and politics of artificial intelligence. Outside of work, she enjoys art, singing, and learning languages. She is passionate about evidence-based policymaking and legislative reform.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Vivan Mukherjee" class="lazy" src="images/nfs/2025/Vivan Mukherjee.png">
				  <h4>Vivan Mukherjee</h4>
				  <p class="position">BA (Political Science), Hindu College</p>
				  <p class="additional_info" style="display:none">A quintessential dilliwala, Vivan Mukherjee is a Political Science graduate from Hindu College, University of Delhi, with a knack for decoding the policy-politics puzzle. Having past experience in research-based roles at NITI Aayog and DeKoder, along with editorial expertise at the National Service Scheme, he blends fieldwork with sharp analysis. Equally passionate about politics as he is about wildlife, he’s just as likely to be found birdwatching or trekking as he is debating international affairs and domestic policy reform. A Real Madrid loyalist and Xbox fanatic, Vivan thrives on meaningful conversations and believes that social change starts with individual effort-and maybe a good assist, on or off the field.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rimsha Khan" class="lazy" src="images/nfs/2025/RimshaKhan.png">
				  <h4>Rimsha Khan</h4>
				  <p class="position">MA (Political Science), Lady Shri Ram College For Women (LSR)</p>
				  <p class="additional_info" style="display:none">Rimsha Khan holds a bachelor’s degree in Biotechnology and a master’s in Political Science from Lady Shri Ram College for Women. Passionate about understanding the world through both science and politics, she finds inspiration in nature, history, and human stories. An avid reader of fiction and history, she enjoys observing the natural world, gazing at the sky, and connecting with people to hear their perspectives. Driven to use her privileges to uplift others and amplify marginalized voices, she aspires to deeply understand Indian politics.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Prachi Bhuckal" class="lazy" src="images/nfs/2025/PrachiBhuckal.png">
				  <h4>Prachi Bhuckal</h4>
				  <p class="position">MA (Political Science), Lady Shri Ram College For Women (LSR)</p>
				  <p class="additional_info" style="display:none">Prachi Bhuckal is a Political Science postgraduate at Lady Shri Ram College with a strong grounding in policy research, leadership, and diplomacy. From publishing research on governance and global affairs to leading college events and policy teams, she brings structure, empathy, and a solutions-oriented mindset to the political space. A former UPSC aspirant, she believes effective consulting is as much about listening as leading. Outside policy circles, you’ll find her choreographing dance routines or experimenting in the kitchen, believing that both, like political consulting, require timing, intuition, and impact. With a passion for inclusive governance and people-first policymaking, Prachi brings empathy, precision, and strategy to the political space, ideally aligned with the vision of the Nehru Fellowship.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Shubham Airi" class="lazy" src="images/nfs/2025/ShubhamAiri.png">
				  <h4>Shubham Airi</h4>
				  <p class="position">LLM (Dispute Resolution), Jindal Global Law School</p>
				  <p class="additional_info" style="display:none">Shubham Airi is a Delhi-based lawyer, policy professional, and social entrepreneur committed to advancing education and access. He holds a BA LLB from Christ University and an LLM in Dispute Resolution from Jindal Global Law School. A former Legislative Assistant to a Member of Parliament under the prestigious LAMP Fellowship, Shubham has contributed to critical policy research, legislative interventions, and public communication. He is the founder of Praxis Education Trust, a non-profit dedicated to democratizing education and skill training in underserved communities. In his legal practice, Shubham specializes in commercial and criminal disputes.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Shivangi Singh" class="lazy" src="images/nfs/2025/SHIVANGI_SINGH.png">
				  <h4>Shivangi Singh</h4>
				  <p class="position">Integrated Dual Degree (Civil Engineering and Biology), BITS Pilani</p>
				  <p class="additional_info" style="display:none">Shivangi Singh is a Dual Degree graduate in Civil Engineering and M.Sc. Biology from BITS Pilani. She is passionate about media, climate equity, and social justice, and has worked on rural education initiatives through Nirmaan NGO. Deeply committed to public service and labor rights, she hopes to better understand India’s political landscape through the Nehru Fellowship. When not discussing politics and philosophy, Shivangi enjoys going out, talking to people, sharing oddly specific memes, and watching documentaries.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Abhishek Pisharody" class="lazy" src="images/nfs/2025/Abhishek Pisharody.png">
				  <h4>Abhishek Pisharody</h4>
				  <p class="position">MA (Development Studies), Azim Premji University</p>
				  <p class="additional_info" style="display:none">Abhishek Pisharody is a Development Studies postgraduate from Azim Premji University with a background in Literature, History, and Philosophy. A former Teach For India Fellow and big-time policy wonk, he is passionate about education, welfare policy, and social equity. A major advocate of good governance and evidence-based policy-making, Abhishek enjoys navigating complexity and distilling it into actionable insight. When not engrossed in his work, he enjoys reading romance novels, improvising at the piano, and playing immersive strategy board games.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Faiz Ashraf" class="lazy" src="images/nfs/2025/FaizAshraf.png">
				  <h4>Faiz Ashraf</h4>
				  <p class="position">MA (Political Science), Jamia Millia Islamia</p>
				  <p class="additional_info" style="display:none">Faiz Ashraf is a Political Science graduate from Jamia Millia Islamia, New Delhi, with extensive experience across research, grassroots organizing, and public policy engagement. He has led community-based projects with NGOs like ORIGIN and Make A Difference, working on education, welfare, and child rights initiatives. As a research assistant at a New Delhi-based law firm, he contributed to legal research and public policy analysis. His academic interests lie in justice, equity, and democratic institutions, drawing upon thinkers like Amartya Sen, John Rawls, and B.R. Ambedkar. Beyond academia, he remains curious about literature, cinema, culinary cultures, and the quiet histories held in old coins.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Mansi Thakare" class="lazy" src="images/nfs/2025/Mansi Thakare_.png">
				  <h4>Mansi Thakare</h4>
				  <p class="position">MA (International Electoral Management and Democracy Practices), Tata Institute of Social Sciences (TISS), and MBA (Social Entrepreneurship), NMIMS</p>
				  <p class="additional_info" style="display:none">Mansi Thakare has completed her Master’s in International Electoral Management and Democracy Practices from TISS. She holds an MBA and has over three years of experience in political campaign strategy, public relations, and grassroots community work. Passionate about gender justice and electoral inclusion, she co-founded ‘constitutional values comic’, a youth group creating a platform where teenagers from every identity can come and share their experience in their unique way that reflects how they feel as Indian citizens. Mansi also brings a deep interest in documentary filmmaking, writing, and constitutional literacy.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Talha Malik" class="lazy" src="images/nfs/2025/Talha_Malik.png">
				  <h4>Talha Malik</h4>
				  <p class="position">PGD (Journalism), Indian Institute of Mass Communication (IIMC)</p>
				  <p class="additional_info" style="display:none">Talha's journey is kind of a maze, she graduated in commerce from Jamia Millia Islamia, then dedicated years to prepare for the Civil Services. But life had other plans for her; her love for writing led her to pursue journalism from the prestigious The Indian Institute of Mass Communication. She has worked with Observer Research Foundation and also as a Sub-editor in Business Standard. When she is not working, you can find her where books are or taking pictures of mundane things and reinterpreting their meanings.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Atul Ranjan" class="lazy" src="images/nfs/2025/Atul Ranjan.png">
				  <h4>Atul Ranjan</h4>
				  <p class="position">PGD (Journalism), Asian College of Journalism</p>
				  <p class="additional_info" style="display:none">Atul Ranjan holds a Postgraduate Diploma in Journalism from the Asian College of Journalism, Chennai, and a Bachelor's degree from the National School of Journalism, Bengaluru. He is also an alumnus of a U.S. exchange program. With reporting experience at NDTV and The Hindu in Delhi, Atul is deeply interested in public affairs, policy, and politics. A keen reader and writer, he aspires to be one of India's leading political correspondents. He values listening as a vital skill—believing that one learns nothing new by only listening to oneself.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Nishat Qasmi" class="lazy" src="images/nfs/2025/Nishat Qasmi.png">
				  <h4>Nishat Qasmi</h4>
				  <p class="position">MA (Philosophy), University Of Delhi</p>
				  <p class="additional_info" style="display:none">Nishat has done her bachelor's and master's in Philosophy from the University of Delhi. It has been her gateway to ask the right questions. From teaching at an NGO to working with a Member of Parliament as a LAMP fellow, the desire to have a first-hand understanding of the state of education in the marginalised communities and how Parliamentarians deal with such issues pushes her to work in avenues that inform her perspective. In the long run, she looks forward to making use of these experiences to make her lectures grounded and fun for her students.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Saurabh Pachpute" class="lazy" src="images/nfs/2025/Saurabh Photo.png">
				  <h4>Saurabh Pachpute</h4>
				  <p class="position">BE (Mechanical Engineering), Savitribai Phule Pune University</p>
				  <p class="additional_info" style="display:none">Saurabh Pachpute graduated with a BE in Mechanical Engineering from Savitribai Phule Pune University and completed the LAMP Fellowship, where he worked closely with a Member of Parliament. He is deeply interested in exploring the rich diversity of India and understanding how people from different backgrounds think about the issues that affect their lives. What drives him is a curiosity to learn how factors like caste, class, religion, region, and local realities influence people’s worldviews and voting preferences. He enjoys reading, meaningful conversations, and meeting people from all walks of life to better understand the everyday thinking that shapes Indian politics.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Zulfikar Ahmed" class="lazy" src="images/nfs/2025/ZulfikarAhmed.png">
				  <h4>Zulfikar Ahmed</h4>
				  <p class="position">MA (International Relations), Jadavpur University</p>
				  <p class="additional_info" style="display:none">Zulfikar Ahmed completed his Master's from the Department of International Relations, Jadavpur University, Kolkata. His research interests include social justice, governance, legal secularism, secularization, and the election machinery. He has worked in Jharkhand, Bihar, and West Bengal as a consultant fellow and as a field associate to elected public representatives. Ahmed is a passionate debater and reader who loves learning new skills and travelling. The three highly revered personalities in his life are Ambedkar, Lenin, and Rajneesh Osho. He firmly believes that civic nationalism and robust constitutionalism are two of the greatest ideas essential to keeping India intact as both a nation and a state.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Siddharth" class="lazy" src="images/nfs/2025/Siddharth Jha.png">
				  <h4>Siddharth</h4>
				  <p class="position">MA (History), Jawaharlal Nehru University (JNU)</p>
				  <p class="additional_info" style="display:none">Siddharth graduated from IIT Kanpur with a degree in Mechanical Engineering, before transitioning to the humanities with a Master's degree in History from Jawaharlal Nehru University. This transition was informed by his preparation for the civil services examination, and he has since garnered experience in the non-profit sector and educational consultancy as well. Apart from a commitment to progressive and inclusive politics, Siddharth is passionate about promoting public transport, walkable cities, and constitutional values in everyday life. He is also an avid proponent of Malabar cuisine, Iranian cinema, and English football.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Parul Harbansh" class="lazy" src="images/nfs/2025/ParulHarbansh.png">
				  <h4>Parul Harbansh</h4>
				  <p class="position">MA (Sociology), Jawaharlal Nehru University (JNU)</p>
				  <p class="additional_info" style="display:none">Parul has a masters in Sociology, which she utilises to analyse the structure and various institutions of modern society. Shaped by nearly a decade in Delhi and two of India’s most politically charged campuses, Delhi University and JNU. Her academic training in sociology and real-world experience in election processes have fuelled a deep interest in how systems work (and how they can work better). As a Nehru Fellow, she’s passionate about building democratic processes that are ethical, inclusive, and effective. When not thinking about politics or policy, she’s either reading a book, smashing forehands in Table Tennis, or absolutely dominating trivia night.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Animesh Shrivastava" class="lazy" src="images/nfs/2025/ANIMESH_NF0041.png">
				  <h4>Animesh Shrivastava</h4>
				  <p class="position">MA (Applied Economics), Jawaharlal Nehru University (JNU)</p>
				  <p class="additional_info" style="display:none">Animesh Srivastava is a graduate in Economics and Political Science from Ramjas College, University of Delhi, and holds a Master’s degree in Applied Economics from the Centre for Development Studies, JNU. He gained early exposure to public policy through a three-month internship at the 16th Finance Commission. Hailing from Allahabad, a city long regarded as a crucible of Indian politics, Animesh’s interest in electoral dynamics was shaped by its legacy of political leadership. As a Nehru Fellow, he aims to deepen his understanding of political structures, campaign strategies, and voter behavior, ultimately working towards his aspiration of becoming a leading psephologist.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Madhav Chadha" class="lazy" src="images/nfs/2025/Madhav.png">
				  <h4>Madhav Chadha</h4>
				  <p class="position">MA (Economics), Ashoka University</p>
				  <p class="additional_info" style="display:none">Armed with a master's degree in economics from Ashoka University, Madhav is passionate about all things politics and policy. You can catch him watching some obscure films or exploring second-hand bookstores over the weekend. He views the Fellowship as an opportunity to explore the intersection of policy, elections, and politics.</p>
				</div>
				</div>
							</div>
		</div>
	</section>
	<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
	<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body team-modal">
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
	
	<script>
	$(document).ready(function() {
		$('[data-bs-target="#modal"]').click(function() {
			$('#modal h5.modal-title').html("<h4>"+$(this).find('h4').html()+"</h4>");
			$('#modal .modal-body').html('<img src="'+$(this).find('img').attr('src')+'" />');
			$('#modal .modal-body').append("<p direction='rtr'>"+$(this).find('p.additional_info').html()+"</p>");
		});
	});
	</script>
</body>
</html>