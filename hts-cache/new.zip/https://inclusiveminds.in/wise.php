<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <title>WISE - Women in Strategy and Electioneering - Inclusive Minds</title>
    <meta name="description" content="Explore WISE (Women in Strategy and Electioneering), India's first exclusive political consulting training program for women. Learn about our comprehensive application process and how this program empowers future women leaders in politics.">
    <meta name="keywords" content="Political Consulting, Election Campaigns, Women in Politics, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
    <meta name="author" content="Inclusive Minds">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="WISE - Women in Strategy and Electioneering - Inclusive Minds">
    <meta property="og:description" content="Explore WISE (Women in Strategy and Electioneering), India's first exclusive political consulting training program for women. Learn about our comprehensive application process and how this program empowers future women leaders in politics.">
    <meta property="og:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x675.jpg">
    <meta property="og:url" content="https://inclusiveminds.in">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="WISE - Women in Strategy and Electioneering - Inclusive Minds">
    <meta name="twitter:description" content="Explore WISE (Women in Strategy and Electioneering), India's first exclusive political consulting training program for women. Learn about our comprehensive application process and how this program empowers future women leaders in politics.">
    <meta name="twitter:image" content="https://inclusiveminds.in//images/inclusive_minds_1200x627.jpg">
    <meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
    <link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
    /* WISE specific color scheme */
    :root {
        --wise-purple: #5d4294;
        --wise-light-purple: #8a70ba;
        --wise-bg-purple: #e6e0f0;
        --wise-dark-text: #333333;
		--wise-dark-purple: #463D8F;
    }
	
	.navbar,.footer {
		background-color: var(--wise-dark-purple) !important;
	}
	
	.nav-link {color:#fff !important;}

    body {
        background: var(--wise-bg-purple) !important;
        color: var(--wise-dark-text);
    }
	

    .hero-section {
		background-image: url('images/wise_bg.jpg?v=1.1.1');
        padding: 60px 0;
		height:auto !important;
    }

    .info-box {
        background-color: white;
        border-radius: 10px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 4px 6px rgba(93, 66, 148, 0.1);
        border-left: 5px solid var(--wise-purple);
    }
	
	.info-box h2 {
		margin-top:-5px !important;
	}

    .info-box i {
        color: var(--wise-purple);
        font-size: 1.8rem;
        float: left;
        margin-right: 15px;
    }

    .section-title {
        color: var(--wise-purple);
        margin-bottom: 15px;
    }

    .btn-action, .apply-btn {
        background-color: var(--wise-purple);
        color: white;
        border: none;
        padding: 10px 25px;
        font-weight: bold;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .btn-action:hover, .apply-btn:hover {
        background-color: var(--wise-light-purple);
        color: white;
        transform: translateY(-2px);
    }

    .timeline-table {
        
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(93, 66, 148, 0.3);
        
		width:100%;
    }

    .timeline-table th {
        background-color: #6d5299;
        color: #ffffff;
        border-color: #6d5299;
		padding:15px;
    }

    .timeline-table td {
        border: 1px solid #6d5299;
		padding:15px;
    }

    .timeline-table tbody tr:hover {
       
    }

    .selection-stage {
        text-align: center;
        padding: 20px;
    }

    .selection-stage h3 {
        margin-top: 10px;
        margin-bottom: 10px;
        font-size: 1.2rem;
        font-weight: bold;
        color: var(--wise-purple);
    }

    .icon {
        font-size: 3rem;
        color: var(--wise-purple); 
    }

    .icon i {
        float: none;
    }

    .display-4, .lead {
        color: var(--wise-purple);
    }

    .tagline, .tagline-mobile {
        color: #fff; //var(--wise-purple);
        font-weight: bold;
    }

    .golden-line, .golden-line-mobile {
        color: color: #fff; //var(--wise-light-purple);
    }
	
	.logo-color-fill { fill: white !important; stroke: white !important; }

    .arrow i {
        color: var(--wise-purple);
        font-size: 1.5rem;
    }

    .hero-content {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(93, 66, 148, 0.15);
        margin-bottom: 30px;
    }

    .highlight-box {
        background-color: white;
        border-radius: 10px;
        padding: 25px;
        height: 100%;
        box-shadow: 0 4px 6px rgba(93, 66, 148, 0.1);
        border-left: 5px solid var(--wise-purple);
        transition: transform 0.3s ease;
    }

    .highlight-box:hover {
        transform: translateY(-5px);
    }

    .highlight-box i {
        color: var(--wise-purple);
    }

    .highlight-box h3 {
        color: var(--wise-purple);
        margin: 0 0 0 0;
        font-size: 1.1rem;
        font-weight: bold;
    }

    /* Mobile responsiveness */
    @media (max-width: 768px) {
        .arrow {
            display: none; 
        }
        
        .timeline-table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
        
        .timeline-table th,
        .timeline-table td {
            padding: 12px;
            font-size: 0.9rem;
        }
    }

    @media (max-width: 991.98px) {
        .col-stage {
            flex-basis: 50%;
            max-width: 50%;
        }
        .arrow {
            display: none; 
        }
    }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>    <section class="hero-section">
        <!-- Content Container -->
        <div class="container position-relative py-5">
            <div class="row align-items-center">
                <!-- Desktop View -->
                <div class="col-lg-4 d-none d-lg-block text-center">
                    <img src="images/wise-logo.svg?v=1.1" class="img-fluid logo-color-fill" alt="WISE Logo" style="max-width: 250px;">
                </div>

                <!-- Desktop View: Right Text (Tagline) -->
                <div class="col-lg-8 d-none d-lg-block">
                    <h2 class="tagline h1">
                        INDIA’S FIRST POLITICAL CONSULTING TRAINING PROGRAM EXCLUSIVELY FOR WOMEN
                    </h2>
                                    </div>
                
                <!-- Mobile View: Centered Content -->
                <div class="col-12 text-center d-lg-none">
                    <img src="images/wise-logo.svg?v=1.1" class="img-fluid mb-4 logo-color-fill" alt="WISE Logo" style="max-width: 200px;">
                    <h2 class="tagline-mobile h2">
                         INDIA’S FIRST POLITICAL CONSULTING TRAINING PROGRAM EXCLUSIVELY FOR WOMEN
                    </h2>
                                    </div>
            </div>
        </div>
    </section>
    <div class="container mt-5" style="margin-bottom:50px;">
        <div class="row g-4">
            <div class="col-12">
                <div class="hero-content text-center info-box" style="margin-bottom:30px !important;height:auto !important;">
                    <h1 class="display-4" style="font-weight:bold;">Women In Strategy And Electioneering</h1>
                    <p class="lead" style="font-weight:bold;">Equipping women with the tools to shape politics</p>
                                        <p class="lead">WISE 2.0 Round 1 Results</p>
                    <a href="wise/" class="btn btn-action apply-btn btn-lg mt-3" style="font-size:26px;">Coming Soon</a>
                                    </div>
                <div style="clear:both;"></div>
            </div>
        </div>
        <div class="row g-4">
            <!-- About the Program -->
            <div class="col-md-6">
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <h2 class="section-title">About the Program</h2>
                    <div class="clear"></div>
                    <p style="text-align:justify">WISE is India's first exclusive training program designed to increase women representation in political consulting. This 100 Days virtual program offers hands-on experience, structured mentorship, and real-world assignments, equipping college students and fresh graduates with the skills and exposure needed to thrive in political consulting. More than just a program, WISE is a bold step towards making political consulting a legitimate and accessible career choice for women.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="info-box">
                   
                    <i class="fas fa-user-graduate "></i>
                    <h2 class="section-title">Eligibility</h2>
                    <div class="clear"></div>
                    <ul>
                        <li>Indian citizens below 25 years of age</li>
                        <li>Women pursuing graduation or recent graduates</li>
                        <li>Can commit a minimum of 4 hours per day for 6 days a week</li>
                        <li>Should have hunger and intent to excel</li>
                                            </ul>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="info-box">
                    <i class="fas fa-question-circle"></i>
                    <h2 class="section-title">Why Choose WISE?</h2>
                    <div class="clear"></div>
                    <ul>
                        <li>Break barriers in a field still distant for many women and claim your space in strategy and leadership</li>
                        <li>Gain hands-on exposure across Political Strategy, Research, Campaigns, Communications, and Data Analytics</li>
                        <li>Contribute meaningfully to live political projects and shape the future of Indian politics</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="info-box">
                    <i class="fas fa-chart-line"></i>
                    <h2 class="section-title">What Will You Gain?</h2>
                    <div class="clear"></div>
                    <ul>
                        <li>An introduction to the inner workings of a political consultancy</li>
                        <li>Hands-on training in Political Intelligence, Research, and Communications</li>
                        <li>Direct learning experience from India’s senior-most political consultants</li>
                        <li>A strong foundation for a future career in political consulting</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-12">
                <div class="info-box">
                    <i class="fas fa-star"></i>
                    <h2 class="section-title">Key Highlights</h2>
                    <div class="clear"></div>
                    <div class="row g-4 mt-2">
                        <div class="col-md-3">
                            <div class="highlight-box ">
                                <i class="fas fa-chalkboard-teacher fa-2x"></i>
                                <h3>Remote Training</h3><br>
                                <p>100 Days remote training program</p>
                            </div>
                        </div>
						<div class="col-md-3">
                            <div class="highlight-box ">
                                <i class="fas fa-project-diagram fa-2x"></i>
                                <h3>Live Political Projects</h3><br>
                                <p>Live political project experience & dedicated mentors</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="highlight-box ">
                                <i class="fas fa-solid fa-chart-bar fa-2x"></i>
                                <h3>Structured Training</h3><br>
                                <p>Structured training in Research, Campaigns, PI, Media & Communications</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="highlight-box ">
                                <i class="fas fa-briefcase fa-2x"></i>
                                <h3>PPO Opportunity</h3><br>
                                <p>₹10,000 monthly stipend & PPO opportunity</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-12">
                <div class="info-box">
                    <i class="fas fa-tasks"></i>
                    <h2 class="section-title">Selection Process</h2>
                    <div class="clear"></div>
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 col-md-3  selection-stage">
                            <div class="icon"><i class="fas fa-file-alt"></i></div> 
                            <h3>Application Submission</h3>
                            <p>A detailed application form along with the SOP</p>
                        </div>
                        <div class="col-md-1 arrow">
                            <i class="fas fa-arrow-right"></i>
                        </div>
                        <div class="col-12 col-md-3  selection-stage">
                            <div class="icon"><i class="fas fa-edit"></i></div>
                            <h3>Written Assignment + R1 Interview</h3>
                            <p>Shortlisted candidates will undergo an assignment and an interview</p>
                        </div>
                        <div class="col-md-1 arrow">
                            <i class="fas fa-arrow-right"></i>
                        </div>
                        <div class="col-12 col-md-3  selection-stage">
                            <div class="icon"><i class="fas fa-user-graduate"></i></div>
                            <h3>Round 2 Interview (Final Interview)</h3>
                            <p>Evaluation of the candidate’s intent, hunger, and alignment with the program’s goals</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="info-box">
                    <i class="fas fa-clock"></i>
                    <h2 class="section-title">Selection Process Timeline</h2>
                    <div class="clear"></div>
                    <div class="timeline-table-section">
                        <table class="timeline-table">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">Stages</th>
                                    <th style="text-align: center;">Dates</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="text-align: center;">Application Window</td>
                                    <td class="timeline-date" style="text-align: center;">7th Nov - 21st Nov, 2025</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;">R1 Interviews + Assignment Submission</td>
                                    <td class="timeline-date" style="text-align: center;">24th Nov - 29th Nov, 2025</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;">R2 Interviews</td>
                                    <td class="timeline-date" style="text-align: center;">3rd Dec - 10th Dec, 2025</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;">Result</td>
                                    <td class="timeline-date" style="text-align: center;">12th Dec, 2025</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;">Program to Start</td>
                                    <td class="timeline-date" style="text-align: center;">5th Jan, 2026</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="info-box">
                    <i class="fas fa-award"></i>
                    <h2 class="section-title">Why is it Worth Your Time?</h2>
                    <div class="clear"></div>
                    <ul>
                        <li>Monthly stipend of ₹10,000</li>
                        <li>PPO opportunity for top performers</li>
                        <li>Certificate of completion</li>
                        <li>Personalised mentorship and regular feedback</li>
                        <li>Letter of Recommendation based on performance</li>
                    </ul>
                </div>
            </div>

            <!-- Apply Now Section -->
            <div class="col-md-6">
                <div class="info-box text-start" id="apply">
                    <div class="">
                        <i class="fas fa-paper-plane"></i>
                        <h2 class="section-title">Ready to Join?</h2>
                        <div class="clear"></div>
                    </div>
                    <p>Take the first step towards an exciting career in political consulting</p>
                                        <a href="wise/" class="btn btn-action apply-btn mt-3">Coming Soon</a>
                                    </div>
            </div>
        </div>
    </div>
    <footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>    
</body>
</html>