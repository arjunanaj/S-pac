<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>Meet Our Fellows 2023 - Inclusive Minds</title>
	<meta name="description" content="Discover the inspiring stories of our fellows from 2023, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta name="keywords" content="Political Consulting, Election Campaigns, Indian National Congress, Data-Driven Strategies, Policy Advisory, Governance Support, Strategic Research, Grassroots Campaigns, Social Media Amplification, Political Strategy, Inclusive Minds, Bengaluru Consultants">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="Meet Our Fellows 2023 - Inclusive Minds">
	<meta property="og:description" content="Discover the inspiring stories of our fellows from 2023, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta property="og:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta property="og:url" content="https://inclusiveminds.in">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Meet Our Fellows 2023 - Inclusive Minds">
	<meta name="twitter:description" content="Discover the inspiring stories of our fellows from 2023, showcasing their leadership journeys and impactful contributions in policy, governance, and community development. Learn how they are shaping the future through their innovative projects and initiatives.">
	<meta name="twitter:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@19.1.3/dist/lazyload.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
	<link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
    .modal-body img {
        float:left;
    }
	body {color:#222;}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>	<section class="about fellow-section py-5" id="about">
		<div class="container">
			<div class="row" style="color:#222;margin-bottom:20px;">
				<div class="col-8">
					<h2 class="fw-bold">Meet our Fellows</h2>
				</div>
				<div class="col-4 text-end">
					<h2 class="text-muted">2023</h2>
				</div>
			</div>
			<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Vikram Sairam" class="lazy" src="images/nfs/Vikram.png">
				  <h4>Vikram Sairam</h4>
				  <p class="position">MA (Public Policy), King's College London</p>
				  <p class="additional_info" style="display:none">Vikram Sairam is a Post Graduate in Public Policy from King’s College, London. Vikram has actively participated in debates and model UN conferences across the country which has allowed him the experience to hone his argumentative and dissenting skills. When not arguing with you, albeit even at a club, with all his heart and soul on everything politics, Vikram will be found stalking the Indian Cricket Team and Manchester United. He is incredibly passionate about his work, evident from the prestigious list of places he has been at - Tony Blair Institute of Global Peace, London, Public Policy Exchange London, and The New Indian Express. The only thing which surpasses our Chennai boy’s passion for politics and debates is his eternal love for idli-sambhar.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Dr. Sunil Pradhan" class="lazy" src="images/nfs/Sunil.png">
				  <h4>Dr. Sunil Pradhan</h4>
				  <p class="position">PhD, School of International Studies, JNU</p>
				  <p class="additional_info" style="display:none">Dr. Sunil Pradhan hails from the mountains of Sikkim and is an academic. A PhD in Comparative Politics and Political Theory from Jawaharlal Nehru University, New Delhi in 2021, he is also the recipient of the prestigious Kodikara Fellowship from the Regional Centre for Strategic Studies (RCSS), Colombo. As an Assistant Professor, he taught  from August 2017 to April 2022 at the Centre for North East Studies and Policy Research at Jamia Millia Islamia, New Delhi. He also taught at the Department of Political Science, Sikkim University. He plans to register and establish a research institute  to cater research that feeds into policy and planning. He writes extensively on issues from Eastern Himalayas and North East India. His articles and book chapters are scopus indexed. He supports Indian Football.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Jehosh Paul" class="lazy" src="images/nfs/jehosh paul.png">
				  <h4>Jehosh Paul</h4>
				  <p class="position">LLM (Law and Development), Azim Premji University</p>
				  <p class="additional_info" style="display:none">Jehosh Paul is a lawyer by training. He holds an LL.M (Law and Development) from Azim Premji University and a B.A. LL.B (Hons.) from the School of Law, CHRIST (Deemed to be University) Bengaluru. Before joining the Nehru Fellowship, Jehosh worked as a Research Assistant at Azim Premji University on a project assigned by the Karnataka Administrative Reforms Commission, Government of Karnataka. His publications have been featured in the Economic &amp; Political Weekly (EPW), Deccan Herald, Times of India, and Oxford Human Rights Hub, among others. As a person belonging to the Hyderabad-Karnataka region, Jehosh intends to work for and contribute towards bringing socio-economic justice to the Hyderabad-Karnataka region.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Prithvi" class="lazy" src="images/nfs/Prithvi.png">
				  <h4>Prithvi</h4>
				  <p class="position">MA Politics (International Studies), JNU</p>
				  <p class="additional_info" style="display:none">Prithvi has completed an MA in International Relations from Jawaharlal Nehru University. He is interested in Public Policy and International Relations. He has graduated with BA (Hons) in Humanities and Social Sciences from University of Delhi where his studies focused towards understanding the intersection of technology and society. He is passionate about learning and exploring new things. He plans to pursue a career as a Political Scientist and aspires to become a Professor in future.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Prateek" class="lazy" src="images/nfs/Prateek.png">
				  <h4>Prateek</h4>
				  <p class="position">BA LLB (Hons.), Gujarat National Law University</p>
				  <p class="additional_info" style="display:none">An Army kid and a sports enthusiast, he dreamt of joining the Armed Forces in his school days, but destiny had other plans for him. He ended up reading a degree in law from GNLU where his tryst with making contributions towards nation building and making a positive impact in the lives of the people began. He lives by the philosophy of ‘passionate yet informed choices’ which is reflected in his unique journey of working under district lawyers to Supreme Court judges, leading NGOs to topmost government offices, each experience broadening his horizon and shaping his perspective. His vision is to see India becoming an egalitarian society in the truest sense and he aims to work in the domain of SDG, which has simplest yet most crucial goals for every individual. He is a budding author trying to capture small wonders in the complexities of daily lives.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Aishwarya Khosla" class="lazy" src="images/nfs/Aishwarya_0018_Layer-1.png">
				  <h4>Aishwarya Khosla</h4>
				  <p class="position">MA (English and Cultural Studies), Panjab University</p>
				  <p class="additional_info" style="display:none">As an editor and feature writer at Hindustan Times, Aishwarya Khosla has had a birds-eye view of the political developments taking place across the country, and has extensively analyzed the prevailing political landscape in Punjab, Haryana, Chandigarh, Himachal Pradesh, and Jammu and Kashmir. Through the fellowship, she hopes to understand the nitty-gritty of planning an election in India, and hone her skills as a political analyst. Aishwarya holds a master’s degree in English and cultural studies from Panjab University, Chandigarh. She has been honored by the Press Information Bureau (Chandigarh) for her write ups on literature and culture and is a two-time winner of the HT Editorial Excellence Award. While she maintains that objectivity is the cornerstone of good journalism, personally, her politics is where her heart is: slightly left-of-center.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Mohammed Habeebullah" class="lazy" src="images/nfs/Habib.png">
				  <h4>Mohammed Habeebullah</h4>
				  <p class="position">Master of Public Policy, Kautilya School of Public Policy</p>
				  <p class="additional_info" style="display:none">Mohammed Habeebullah is a post graduate in Public Policy from the Kautilya School of Public Policy. Habeeb is spontaneous and loves to delve deep into the heart of things, something which his professional journey has thus far shown. His love for politics goes beyond the usual debates and discussions. Habeeb’s interest in gaining a first-hand lived experience of the common Indian man, took him to Swiggy for a stint as a delivery boy. He has worked with the Government of Telangana and also done political consultancy for a regional party. His favorite word in the world is “what” which essentially captures his innate yearning for knowledge and prolonged discussions. Habeeb’s love for electoral politics is surpassed only by his love for cars, bikes and FOOD. The in-house Food Connoisseur amongst the NF’s, he is the go-to person for any food recommendation which will always be served with a side dish of why Visag is the best city in the world.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Thomas Karthik Varghese" class="lazy" src="images/nfs/Thomas.png">
				  <h4>Thomas Karthik Varghese</h4>
				  <p class="position">MA (Economics), Madras School of Economics</p>
				  <p class="additional_info" style="display:none">Thomas Karthik Varghese is a Post-Graduate in Economics from Madras School of Economics, who was in his early career stage in the marketing analytics field. Being a curious and confused person, he decided to give one of his interests a try, leading to joining the Nehru Fellowship. As an ambivert caught between the realms of introversion and extroversion, you can see him silently observing from a corner with contemplation and being completely free with his close friends. His favorite time pass is just simply passing time with his friends. And yeah, whatever you say, you can see him comparing it with how it is in Kerala.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Tanuvi Riti Thakur" class="lazy" src="images/nfs/Tanuvi .png">
				  <h4>Tanuvi Riti Thakur</h4>
				  <p class="position">MA (Economics), Cotton University</p>
				  <p class="additional_info" style="display:none">Tanuvi Riti Thakur is an Economics Post Graduate from Guwahati, Assam and a former LAMP Fellow. The ultimate RaGa fangirl, Tanuvi’s interest in politics is obtrusive through just a few conversations with her.  Her work and fast thinking approach,  reflects her  past experience of  working around Tech Policy and gaining a variety of skills such as project management, liaison with government officials, communication and research. Her future plans include working with multilateral institutions, specifically in areas that lie at the intersection of technology, development and rights. On the personal front, she intends to live in a big house of her own with Breezer, her one year old golden retriever. The fashionista among the Nehru Fellows, on weekends (or weekdays!) you will find Tanuvi at H&amp;M, IKEA or anywhere that involves shopping.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Harshita Vaddadi" class="lazy" src="images/nfs/Harshita.png">
				  <h4>Harshita Vaddadi</h4>
				  <p class="position">MSc (Behavioural Economics), University of Essex</p>
				  <p class="additional_info" style="display:none">Harshita Vaddadi is a Behavioral Economics graduate from the University of Essex and a former Young India Fellow.  Prior to joining the Nehru Fellowship, Harshita has worked with Mintz, Mumbai for a brief period as a due diligence investigator. Her experiences also include an impactful stint at Pratham which involved improving educational accessibility for children in rural areas. She seeks to utilize her diverse work experience combined with her knowledge and passion for  behavioral economics to  create user-friendly  public policies grounded in behavioral economics and nudge theory principles. As a true loyalist to her  hometown, this Vizag girl loves walking by the beaches,  fitting a swim in her hectic daily  routine and trying to brew the perfect cup of coffee.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Sanskriti" class="lazy" src="images/nfs/Sanskriti.png">
				  <h4>Sanskriti</h4>
				  <p class="position">BA Philosophy (Hons.), Miranda House, University of Delhi</p>
				  <p class="additional_info" style="display:none">Sanskriti truly epitomizes her name. She is enthusiastic about all things cultural; filled with rigor and zest for life, she is a people’s person and fills every space she occupies with a positive energy that’s infectious! Hailing from the heart of India; Madhya Pradesh, she has done her undergraduate studies from Miranda House, University of Delhi, where she read philosophy and was a keen participant in various college activities. She draws inspiration from nature and expresses it through theater, dance and poetry. During college, she headed a college sorority (Gandhi Study Circle) in the capacity of the President and conducted various activities at a time when the entire world had shut down (2020-21) and helped keep the morale of the members high. She wants to create a peaceful space by contributing in administration or by working in good governance and public policy. She aspires to start with villages and transform them into what Gandhi called an ideal village by applying her creative approach and problem solving skills.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Mohammad Juned Shahil" class="lazy" src="images/nfs/Juned.png">
				  <h4>Mohammad Juned Shahil</h4>
				  <p class="position">Master of Public Policy, Kautilya School of Public Policy</p>
				  <p class="additional_info" style="display:none">Mohammad Juned Shahil, an accomplished engineer with a background in the IT sector, chose to embark on a transformative journey by pursuing a Master’s in Public Policy at the prestigious Kautilya School of Public Policy—driven by an unwavering passion for driving change and positively impacting society. He firmly believes evidence-based policy-making is a new paradigm and is fascinated by how politics shape the country's policies. He wants to understand the interplay between policy-making and politics and make tangible contributions toward societal development. His area of interest lies in issues of representation and empowerment. He keenly follows the contemporary developments of social policies across geographies. He believes contributing to the nation's politics is the way to bring desirable change.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Suvidhi" class="lazy" src="images/nfs/Suvidhi.png">
				  <h4>Suvidhi</h4>
				  <p class="position">MA (Diplomacy, Law &amp; Business), O.P. Jindal Global University</p>
				  <p class="additional_info" style="display:none">Born and brought up in the country's power center, Delhi, Suvidhi is the most apolitical Political Consultant you would come across with, except for looking up to Rahul Gandhi for inspiration. This OG flagbearer of RaGa politics is a graduate from University of Delhi and currently pursuing PG from OP Jindal Global University. Dynamic and responsible beyond her age, she is a powerhouse who takes no time in becoming the soul of every gathering, both formal and informal. She is a binding thread who can transform a bunch of people into a team and lead them effectively. During her free time, she can be found being an Instagramjeevi.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Hirak J Sharma" class="lazy" src="images/nfs/Hirak.png">
				  <h4>Hirak J Sharma</h4>
				  <p class="position">MA Social Work (Community Organisation and Development Practice), Tata Institute of Social Sciences</p>
				  <p class="additional_info" style="display:none">Hirak J Sharma completed his Master's degree in Social Work with a specialization in Community Organization and Development Practice from TISS. He started his career as a state manager for UNICEF in Ranchi, Jharkhand, and later worked as a Legislative Research Fellow under the Meghalaya Legislative Research Fellowship program by the Government of Meghalaya. His interests revolve around youth development, sustainable community-level development, quality education in India, climate change, intersectional feminism, good governance, public policy, and politics.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Nisarg Shah" class="lazy" src="images/nfs/Nisarg.png">
				  <h4>Nisarg Shah</h4>
				  <p class="position">BE (Manufacturing Engineering), Gujarat Technological University</p>
				  <p class="additional_info" style="display:none">Nisarg Shah is an Engineer by education and a  Businessman by family lineage, he has a unique perspective towards politics. For him,  politics impacts everything and everything impacts politics. This comes from his deep understanding of the country's complex political spectrum and his respect for every individual’s political belief.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Anandita Pathak" class="lazy" src="images/nfs/Anandita.png">
				  <h4>Anandita Pathak</h4>
				  <p class="position">BA History (Hons.), University of Delhi</p>
				  <p class="additional_info" style="display:none">Anandita Pathak is a graduate in History from the University of Delhi. She is an avid reader, skilled researcher and loves making charts! She is passionate about gender and politics, and her work at UNICEF which involved on-ground engagement with state and local government stakeholders in Assam, is reflective of her core interests. She has been actively engaged in promoting Sexual and Reproductive Health Rights, specifically abortion rights for women. When not reading, working or listening to music, Anandita can be found drooling over cat videos on Instagram. She is a proud momma to Aador and Ekhud, her two beautiful cats. She is the quintessential elder sister in any friend group and has been accused of being too responsible.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Varun Desai" class="lazy" src="images/nfs/Varun.png">
				  <h4>Varun Desai</h4>
				  <p class="position">ADMA (Advertising &amp; Marketing Communications), Xavier Institute of Communications</p>
				  <p class="additional_info" style="display:none">An AD MAN, Art, Adventure and Sports Enthusiast, he graduated from XIC, Mumbai after completing his PGDM in Advertising and Marketing Communications. Desai brings about three years of industry experience working in client servicing, brand strategy and as a liaison between agency and clients since he began his career at BBDO India in July 2019. He then moved to Leo Burnett Orchard (PUBLICIS GROUPE) in 2020. Most recently he did a short stint at McCann WORLDGROUP as Senior Project Manager. He is a music lover, enjoys good food, cooking and loves to travel. He wishes to become an all-round communications expert and continue exploring his many passions of collecting shoes, watches and vintage cars amongst other varied interests.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Ritesh" class="lazy" src="images/nfs/Ritesh.png">
				  <h4>Ritesh</h4>
				  <p class="position">BS Economics, IIT Kanpur</p>
				  <p class="additional_info" style="display:none">Borrowing words from Lenka’s Everything at Once, as cool as a tree, as scary as sea, Ritesh is an epitome of dedication on every field he steps on. He is yet another valuable contribution of IIT-K to the field of political consultancy. Strong like a family, strong as he wanna be, he has rightly earned the title of ‘A Family Man’ as he takes care of his own family and office family really well. A combat athlete, when he is not busy fighting with a complex task or working on a political situation, he can be found in a boxing ring or on a football field.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Swati Bisen" class="lazy" src="images/nfs/Swati.png">
				  <h4>Swati Bisen</h4>
				  <p class="position">LLM (International Law), Fletcher School of Law and Diplomacy</p>
				  <p class="additional_info" style="display:none">A spirited legal scholar, has a background in International Law and Human Rights. With a Master of Laws from The Fletcher School of Law and Diplomacy, she has been ardently involved in research and teaching. Swati's work at HAQ: Center for Child Rights and her publications reflect her commitment to social justice. Her passion for politics, particularly of her home state, Uttar Pradesh, led her to join the Nehru Fellowship where she worked on complex sociopolitical issues. She is eager to contribute her knowledge and skills to create a positive impact in the political landscape.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Aastha Rathore" class="lazy" src="images/nfs/Aastha.png">
				  <h4>Aastha Rathore</h4>
				  <p class="position">PGD (English Journalism), IIMC, New Delhi</p>
				  <p class="additional_info" style="display:none">Aastha Rathore is a person with multiple passions owing to rich academic and co-curricular experiences. She is a Math(Hons.) graduate with a PGD in English Journalism from IIMC, New Delhi and a background in theater and public speaking. She worked as a Senior Sub-Editor, Anchor and Producer at The Lallantop, India Today Group before joining the Fellowship. Aastha is an avid reader who also enjoys writing, painting and dancing. Her love for literature, history, performing arts, society, politics, science and almost everything under the sun has contributed to her personal and professional growth. Factors, she claims, have enabled her to own and further hone a diverse skill set. One should always keep learning and widening their horizon for the better - she operates on that notion!</p>
				</div>
				</div>
							</div>
		</div>
	</section>
	<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
	<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body team-modal">
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
	
	<script>
	$(document).ready(function() {
		//$('.lazy').lazy();
		$('[data-bs-target="#modal"]').click(function() {
			$('#modal h5.modal-title').html("<h4>"+$(this).find('h4').html()+"</h4>");
			$('#modal .modal-body').html('<img src="'+$(this).find('img').attr('src')+'" />');
			$('#modal .modal-body').append("<p direction='rtr'>"+$(this).find('p.additional_info').html()+"</p>");
		});
        /* var lazyLoadInstance = new LazyLoad({
        // Your custom settings go here
        }); */
	});
	</script>
</body>
</html>