<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
    <title>WISE 2025 - Women in Strategy and Electioneering - Inclusive Minds</title>
	<meta name="description" content=" Meet our WISE Trainees - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta name="keywords" content="WISE, Women in Strategy, Political Consulting, Election Campaigns, Women Leadership, Political Strategy, Inclusive Minds, Women Empowerment">
	<meta name="author" content="Inclusive Minds">
	<meta name="robots" content="index, follow">
	<meta property="og:title" content="WISE 2025 - Women in Strategy and Electioneering - Inclusive Minds">
	<meta property="og:description" content="Meet our WISE Trainees 2025 - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta property="og:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta property="og:url" content="https://inclusiveminds.in/wise_2025.php">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="WISE 2025 - Women in Strategy and Electioneering - Inclusive Minds">
	<meta name="twitter:description" content="Meet those who onboarded to WISE 2025 - Women in Strategy and Electioneering program. Discover inspiring women who are shaping the future of political consulting through our exclusive training program.">
	<meta name="twitter:image" content="https://inclusiveminds.in/images/og-image.jpg">
	<meta name="twitter:site" content="@INClusive_Minds">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@19.1.3/dist/lazyload.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,800;1,800&display=swap" rel="stylesheet">
	<link href="css/style.css?v=1.0.10" rel="stylesheet">
    <style>
    .modal-body img {
        float:left;
    }
	body {color:#222;}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
	<div class="container">
		<a class="navbar-brand" href="/">
			<div style="float:left;"><img src="/images/logo.svg" style="width:57px;height:30px;" /></div>
			<div style="float:left;font-size:25px;margin-left:10px;margin-top:-2px;">Inclusive Minds</div>
			<div style="clear:both;"></div>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ms-auto">
				<li class="nav-item">
					<a class="nav-link" href="/#about">About Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#work">Our Work</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						Nehru Fellowship
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/nehru-fellowship.php">About Fellowship</a></li>
						<li><a class="dropdown-item" href="/nf_2023.php">Fellows 2023</a></li>
						<li><a class="dropdown-item" href="/nf_2024.php">Fellows 2024</a></li>
						<li><a class="dropdown-item" href="/nf_2025.php">Fellows 2025</a></li>
						
					</ul>
				</li>
			
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						WISE Training Program
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="/wise.php">About WISE</a></li>
						<li><a class="dropdown-item" href="/wise_2025.php">Wise 2025</a></li>
						<li><a class="dropdown-item" href="/wise_2026.php">Wise 2026</a></li>
						
						
					</ul>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/#join">Join Us</a>
				</li>
			</ul>
		</div>
	</div>
</nav>	<section class="about wise-section fellow-section py-5" id="about">
		<div class="container">
			<div class="row" style="color:#222;margin-bottom:20px;">
				<div class="col-8">
					<h2 class="fw-bold">Meet our WISE Trainees</h2>
				</div>
				<div class="col-4 text-end">
					<h2 class="text-muted">2025</h2>
				</div>
			</div>
						<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Apoorva Singh" class="lazy" src="images/wise/2025/Apoorva Singh.png">
				  <h4>Apoorva Singh</h4>
				  <p class="position">Economics and Public Policy Scholar, University of York</p>
				  <p class="additional_info" style="display:none">Apoorva Singh is an Economics and Public Policy scholar at the University of York, England, currently researching policies for social welfare and income generation. She recently won the York Award for her commitment to personal and professional growth through academics and career development. In addition to being a WISE fellow, she serves as an Education and Sustainability Coordinator at the University of York, working to reduce textile waste and clothing poverty among students. She completed her undergraduate studies at the University of Delhi. Her multilingual skills in English, Hindi, and Spanish further demonstrate her passion for learning. Her hobbies include singing, dancing, and poetry. She enjoys discovering new ways to serve nature and humankind.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Lucy Grace Tang" class="lazy" src="images/wise/2025/Lucy Grace Tang.png">
				  <h4>Lucy Grace Tang</h4>
				  <p class="position">M.A. in Social Work, Tata Institute of Social Sciences</p>
				  <p class="additional_info" style="display:none">Lucy holds a Master’s degree in Social Work with a specialization in Counselling from the Tata Institute of Social Sciences, Guwahati campus. She is passionate about mental health, child and women development, and community well-being. She is also dedicated to working closely with people to create meaningful change. Outside of her professional interests, she enjoys reading, painting, and meeting new people.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Kaushiki Ishwar" class="lazy" src="images/wise/2025/Kaushiki Ishwar.png">
				  <h4>Kaushiki Ishwar</h4>
				  <p class="position">Young India Fellow, Ashoka University</p>
				  <p class="additional_info" style="display:none">Kaushiki Ishwar is a Young India Fellow at Ashoka University and a graduate of Miranda House, where she pursued a double major in Philosophy and History with a minor in Sociology. Her work explores oral histories and the silences of marginalized communities through historical preservation, grounded in poststructuralist and critical theory. She is the founder of Critikal &amp; Theorie, a publishing initiative committed to radical thought and resistance literature. Kaushiki has also served as the International Training Head and Debate Coach for Team India, mentoring over 3,500 students over the course of 3 years in the education sector.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Prerana Rajesh Tiwari" class="lazy" src="images/wise/2025/Prerana Tiwari.png">
				  <h4>Prerana Rajesh Tiwari</h4>
				  <p class="position">M.A. in Politics, University of Mumbai</p>
				  <p class="additional_info" style="display:none">Prerana Tiwari is drawn towards how people, systems, and change are connected, especially through the deeper and often invisible patterns that shape everyday life and society. She holds an M.A. (Honors) in Politics from the University of Mumbai, and is building her path at the intersection of research, strategy, and global affairs, committed to ideas that create meaningful impact. Prerana is perpetually curious, her love for history, psychology, art, literature, and spirituality helps her deepen the understanding of human behavior and to see how the personal and political are intertwined. She enjoys writing, travel, and dance and sees them as ways of observing, reflecting, and staying connected to what informs her thinking and purpose. Prerana approaches her work with clarity, conviction, and care. She believes that meaningful strategy must engage both intellect and emotion to truly transform.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Salony Kumari" class="lazy" src="images/wise/2025/Salony.png">
				  <h4>Salony Kumari</h4>
				  <p class="position">Political Science Student, Lady Shri Ram College for Women</p>
				  <p class="additional_info" style="display:none">Salony is a student of Political Science Honours with a minor in Economics at Lady Shri Ram College for Women, University of Delhi. Her academic curiosity extends beyond classrooms- exploring the dynamic intersections of politics, policy, and society through writing and fieldwork. She has authored articles on social justice and governance for platforms like The Wire, and has written on legal developments for The Leaflet. Her research has also been featured in Poletariat, her department’s political science newsletter. A firm believer in the power of education, Salony envisions a future where policy and pedagogy meet to ensure equitable access to quality learning. While she thrives in the energy of elections, treating them like national festivals, her deeper calling lies in long-term reform and people-centric policymaking. An active English debater and youth parliament participant, she loves diving into wicked questions and open-ended arguments, believing that sometimes, the best conversations don’t need tidy conclusions.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Roshni Veronika Mallick" class="lazy" src="images/wise/2025/Roshni Veronika Mallick.png">
				  <h4>Roshni Veronika Mallick</h4>
				  <p class="position">M.A. in Public Policy Student, NLSIU Bengaluru</p>
				  <p class="additional_info" style="display:none">Roshni Veronika Mallick is currently pursuing a Master’s in Public Policy at the National Law School of India University, Bengaluru. She holds a Bachelor’s degree in English from Jadavpur University. Her academic and professional pursuits reflect a deep commitment to equity, ethics, and inclusive policymaking. Outside of academics, she enjoys reading literary fiction, exploring global affairs, and engaging in public debate.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Muskan Punia" class="lazy" src="images/wise/2025/Muskan Punia.png">
				  <h4>Muskan Punia</h4>
				  <p class="position">M.A. in Politics and International Studies, JNU</p>
				  <p class="additional_info" style="display:none">Muskan holds a master's degree in Politics and International Studies from Jawaharlal Nehru University. Her professional journey reflects a wide-ranging set of experiences from working closely with Tibetan communities in Dharamshala to being on the ground in West Bengal during the 2024 Lok Sabha elections. She has been instrumental in building and managing the Ministry of Culture's internship program, guiding four cohorts of interns. She is keen on learning and experiencing new things. She's a part-time researcher and deeply passionate about working with people, understanding politics, history and culture, and making sense of the ever-evolving world around us.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Navneedhi Meena" class="lazy" src="images/wise/2025/Navneedhi Meena.png">
				  <h4>Navneedhi Meena</h4>
				  <p class="position">Economics Graduate, Miranda House</p>
				  <p class="additional_info" style="display:none">Navneedhi Meena, from Jaipur, Rajasthan, earned her bachelor's degree in Economics from Miranda House, University of Delhi. Intrigued by the art of policymaking, she began her public-policy journey through policy drafting competitions, followed by internships at policy think tanks and working at an MP’s office. She has authored research papers on topics ranging from unemployment to sustainability. She is a public policy enthusiast and a firm believer in data-driven policymaking. Additionally, she is a cinephile at heart, always up for a good movie.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rituparna Shekhar" class="lazy" src="images/wise/2025/Rituparna Shekhar.png">
				  <h4>Rituparna Shekhar</h4>
				  <p class="position">Fellow, Teach For India</p>
				  <p class="additional_info" style="display:none">Rituparna is a spirited and thoughtful individual who finds joy in the everyday and magic in teaching. A graduate in English Literature from Ramjas College, University of Delhi, she is currently working as a Fellow with Teach For India, where her classroom is her happiest place. With a strong feminist lens and a mind that loves to question the unquestioned, Rituparna brings depth and reflection into everything she does. When she’s not teaching or challenging norms, you’ll find her swimming, cooking, or discovering the best food spots in town, so much so that friends always turn to her for food recommendations!</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Yukti Kapil" class="lazy" src="images/wise/2025/Yukti Kapil.png">
				  <h4>Yukti Kapil</h4>
				  <p class="position">Political Science Graduate, Miranda House</p>
				  <p class="additional_info" style="display:none">Yukti Kapil has pursued BA (hons) in Political Science from Miranda house, University of Delhi. Drawing from her deep interest in political science, politics, public policy, political economy, geo-politics, Yukti has deepened her knowledge through multiple certifications, including a Certificate in Public Policy from the Centre for Civil Society and a Legal Literacy Course in collaboration with the Delhi State Legal Services Authority. Her past area of study includes preliminary work on voting behaviour in the 2024 Indian General Elections. Yukti has engaged in a nationally telecasted youth dialogue on foreign policy on DD India. Beyond academics, Yukti likes to write, play guitar and sketch in her leisure time. She was also part of an Anthology, 'More than a Word'.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Samyuktha Anuram" class="lazy" src="images/wise/2025/Samyuktha Anuram.png">
				  <h4>Samyuktha Anuram</h4>
				  <p class="position">Law Student, Gujarat National Law University</p>
				  <p class="additional_info" style="display:none">Samyuktha Anuram is a final-year B.A. LL.B. (Hons.) student at Gujarat National Law University. Her academic interests lie at the intersection of policy, governance, disability rights and investment law. As a dedicated researcher, she has contributed to publications on disability rights, environmental law, and policy analysis. Samyuktha enjoys reading and working on accessibility reforms. As a NCC Senior Under Officer and convenor of the GNLU Centre for Disability Studies, she actively blends discipline with advocacy. She is passionate about leveraging law to drive inclusive and sustainable change.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Harshita Gupta" class="lazy" src="images/wise/2025/harshita.png">
				  <h4>Harshita Gupta</h4>
				  <p class="position">Undergraduate Student, Mount Carmel College</p>
				  <p class="additional_info" style="display:none">Harshita Gupta is a third-year undergraduate student at Mount Carmel College, Bengaluru, pursuing a B.A. in Political Science and Sociology. With a strong foundation in humanities and a deep passion for public policy, she aspires to create meaningful change through inclusive and impact-driven governance. Originally from Kolkata, Harshita has led non-profit initiatives, participated in fellowships like Policy in Action and One Future and actively engages in policy research and civic advocacy. Her interests span debating, cinema, writing, reading and music.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Vidhi Sharma" class="lazy" src="images/wise/2025/Vidhi Sharma.png">
				  <h4>Vidhi Sharma</h4>
				  <p class="position">M.A. in Culture, Society and Thought, IIT Delhi</p>
				  <p class="additional_info" style="display:none">Vidhi is a 2024 graduate in English Honours from Hindu College, DU. She pursued a distance PG Diploma in Human Rights Law from NLSIU Bengaluru thereafter and is an incoming student at IIT Delhi for an M.A. in Culture, Society and Thought. She loves to read, write, engage in any and every sport, and can be found rabbit holing on the net in her free time. Sylvia Plath’s fig tree analogy is her roman empire. Her personal, tad-bit-unrealistic life goal remains wanting to know something of everything and everything of something.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Pranjal Chauhan" class="lazy" src="images/wise/2025/Pranjal Chauhan.png">
				  <h4>Pranjal Chauhan</h4>
				  <p class="position">M.A. in Gender Studies Student, Ambedkar University</p>
				  <p class="additional_info" style="display:none">Pranjal is a passionate student of history and culture, with a Bachelor's degree in History (Hons) from Kamla Nehru College, Delhi University. She is currently pursuing her Master’s in Gender Studies from Ambedkar University. Alongside her academic journey, Pranjal is also a semi-professional badminton player, balancing sports and studies with equal dedication. Deeply committed to community engagement, she has worked with the NGO CEQUIN in their communications department, contributing to initiatives focused on gender equality and empowerment. Pranjal’s interests lie at the intersection of heritage, gender, and social justice, reflecting her multifaceted personality and drive.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Jigmet Norzin" class="lazy" src="images/wise/2025/Jigmet Norzin.png">
				  <h4>Jigmet Norzin</h4>
				  <p class="position">M.A. in Political Science, Panjab University</p>
				  <p class="additional_info" style="display:none">She is Jigmet Norzin , from Leh Ladakh . She has done her MA in political science from Panjab University and BA honours in Political science from Post graduate government college sector 11 D. She also holds UGC NET certificate in political science.She is someone who aims to spread political awareness among villagers (specifically Ladakh )who have been deprived of their voting rights.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Rashmika Sharma" class="lazy" src="images/wise/2025/Rashmika Sharma.png">
				  <h4>Rashmika Sharma</h4>
				  <p class="position">Sociology Major &amp; Policy in Action Fellow</p>
				  <p class="additional_info" style="display:none">A Sociology major, Rashmika is curious about how policy, technology, and governance shape the world around us. Her interest in all things governance began during the pandemic, when she volunteered with a youth-led non-profit in the education sector. Since then, she has been a Policy in Action Fellow with YLAC (Young Leaders for Active Citizenship) and is now excited to be part of WISE! Outside of work, she’s either at the nearest PVR watching a movie or convincing herself she’ll finally learn the ukulele next week.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Sandra Maria Varghese" class="lazy" src="images/wise/2025/Sandra Maria Varghese.png">
				  <h4>Sandra Maria Varghese</h4>
				  <p class="position">Third-year Law Student</p>
				  <p class="additional_info" style="display:none">Sandra Maria Varghese is a third-year law student pursuing excellence in criminal and corporate laws, with a passion for impactful advocacy. She’s into good reads featuring classic “whodunnit” murder plots and courtroom dramas. She’s a trained Karnatic singer, a foodie, and a devoted fan of 90's sitcoms. She's always looking forward to efficient networking and productive exposures. Any conversation about feminism, patriarchy, or human rights—and you have her full attention!</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Anoushka Purohit" class="lazy" src="images/wise/2025/Anoushka.png">
				  <h4>Anoushka Purohit</h4>
				  <p class="position">Political Science Graduate, University of Delhi</p>
				  <p class="additional_info" style="display:none">Anoushka Purohit is a Political Science graduate from University of Delhi, with a deep-rooted interest in regional politics and grassroots governance. Hailing from Odisha, her academic work and public engagements often center around the evolving dynamics of Indian federalism and political representation. She has been closely involved in student research, public campaigns, and policy-centered writing, often blending the personal with the political in her work. When she’s not dissecting the latest developments in regional politics, you’ll find her sketching cityscapes, hunting for political fiction that cuts deep, or religiously updating her Letterboxed lists. Her dream cocktail? Good cinema, sharper statecraft, and an unapologetic love for coastal way of life.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Thenthamizh S S" class="lazy" src="images/wise/2025/Thenthamizh S.png">
				  <h4>Thenthamizh S S</h4>
				  <p class="position">Undergraduate Economics Student</p>
				  <p class="additional_info" style="display:none">Thenthamizh is an undergraduate Economics student with a minor in Data Analytics. She's the Cofounder and Managing Editor of Political Pandora, a global youth-led publication. She previously founded a Dream Equal chapter to promote gender equality and currently leads Aawaz, a campus forum she started to cultivate civic dialogue and challenge the status quo. Her passion for economics and politics took root in two forms: a deep commitment to equality &amp; an intellectual curiosity about systems that shape our world. This carries into her focus on economics for development, building a strong foundation in data, policy, and analysis to make lasting impact.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Santhiya M" class="lazy" src="images/wise/2025/Santhiya M.png">
				  <h4>Santhiya M</h4>
				  <p class="position">Political Science Undergraduate, Madras Christian College</p>
				  <p class="additional_info" style="display:none">Santhiya is a passionate Political Science undergraduate at Madras Christian College with a strong interest in psephology, gender studies, and public policy. She has contributed to public-oriented initiatives like the Tamil Nadu government’s Naan Mudhalvan program and is currently a research intern exploring key political and policy issues. An avid debater and Model UN presiding officer, she hopes to shape her journey into that of a political scientist. When not volunteering or doing MUNs, she is likely dancing or enjoying good food, bringing the same energy and curiosity to life that she brings to politics.</p>
				</div>
				</div>
								<div class="col-md-3" data-bs-toggle="modal" data-bs-target="#modal">
				<div class="team-member"  style="min-height:250px;">
				  <img alt="Garvita Maheshwari" class="lazy" src="images/wise/2025/Garvita Maheshwari.png">
				  <h4>Garvita Maheshwari</h4>
				  <p class="position">M.A. in Management Student, IIM Indore</p>
				  <p class="additional_info" style="display:none">Garvita is currently pursuing her Master’s in Management from IIM Indore. Earlier, she has interned at DCM Shriram, gaining practical experience in strategic research and analysis. Her time in college sparked a strong interest in politics, which she believes can be a transformative tool for addressing real societal challenges.She aspires to challenge conventional narratives and contribute to more inclusive and accountable governance. Beyond her professional pursuits, she enjoys playing chess and love to paint.</p>
				</div>
				</div>
							</div>
					</div>
	</section>
	<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="copyright">© 2026 All Rights Reserved</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <ul class="social-icons list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com/TheInclusiveMinds/" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.linkedin.com/company/inclusive-minds-ind" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
						<a href="https://twitter.com/inclusive_minds" target="_blank" aria-label="X (formerly Twitter)">
							<i class="fa-brands fa-x-twitter"></i>
						</a>
					</li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com/theinclusiveminds/" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6109SPYQJ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6109SPYQJ1');
</script>
	<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body team-modal">
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
	
	<script>
	$(document).ready(function() {
		$('[data-bs-target="#modal"]').click(function() {
			$('#modal h5.modal-title').html("<h4>"+$(this).find('h4').html()+"</h4>");
			$('#modal .modal-body').html('<img src="'+$(this).find('img').attr('src')+'" />');
			$('#modal .modal-body').append("<p direction='rtr'>"+$(this).find('p.additional_info').html()+"</p>");
		});
	});
	</script>
</body>
</html>